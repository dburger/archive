package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import edu.hawaii.sitewatch.control.Page;

/**
 * An interface to support the Command pattern for action dispatching in the MVC framework for JSP
 * page serving. All command instances should take a request and response object, extract any
 * additional parameters necessary, do processing and store the results in the request object, then
 * return the Page instance that should be dispatched to for displaying the results.
 *
 * @author Philip M. Johnson
 * @author Jitender Miglani (did minor changes)
 * @version $Id: Command.java,v 1.4 2003/12/04 20:43:10 dburger Exp $
 */
public interface Command {

  /**
   * Processes a request from the user.
   *
   * @param request The request object, from which additional data concerning
   *     the user request can be extracted.
   * @return The page that should be dispatched to next.
   */
  public Page process(HttpServletRequest request);
  
}
