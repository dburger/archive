package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Test the action of the user changing their password.
 *
 * @author David J. Burger
 * @version $Id: TestChangePassword.java,v 1.7 2003/12/04 22:30:06 dburger Exp $
 */
public class TestChangePassword extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the change password operation under normal operation.
   *
   * @throws Exception If problems occur
   */
  public void testChangePassword() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";

    // attempt to login with the test account
    assertLogin(conversation, userId, password);

    // get the changepassword.jsp page and check for successful retrieval
    WebResponse response = conversation.getResponse(testHost + "sitewatch/changepassword.jsp");
    assertEquals("Expecting changepassword.jsp page.", Page.CHANGE_PASSWORD.getTitle(),
        response.getTitle());

    // attempt to change the password to "changed"
    String newPassword = "changed";
    WebForm ChangePasswordForm = response.getFormWithID("ChangePasswordForm");
    WebRequest changePasswordRequest = ChangePasswordForm.getRequest();
    changePasswordRequest.setParameter("password", password);
    changePasswordRequest.setParameter("newPassword1", newPassword);
    changePasswordRequest.setParameter("newPassword2", newPassword);
    response = conversation.getResponse(changePasswordRequest);

    // should have gone to the index page
    assertEquals ("Expecting index.jsp page retrieval", Page.INDEX.getTitle(), response.getTitle());

    // and there should be a message that says that have changed their password
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting change password confirmation message.", "You have successfully changed "
        + "your password. Please remember it for future use.", messageTable.getCellAsText(0, 0));

    // now log out
    WebLink signOutLink = response.getLinkWith("sign out");
    response = conversation.getResponse(signOutLink.getRequest());

    // now check that directed back to the welcome page
    assertEquals("Expecting to retrieve welcome.jsp page.",
        Page.WELCOME.getTitle(), response.getTitle());

    // now attempt to login with the new password
    assertLogin(conversation, userId, newPassword);

    // finally change the password back for further tests,
    // first, get changepassword.jsp and check for successful retrieval
    response = conversation.getResponse(testHost + "sitewatch/changepassword.jsp");
    assertEquals("Expecting changepassword.jsp page.",
        Page.CHANGE_PASSWORD.getTitle(), response.getTitle());

    // now change the password back
    ChangePasswordForm = response.getFormWithID("ChangePasswordForm");
    changePasswordRequest = ChangePasswordForm.getRequest();
    changePasswordRequest.setParameter("password", newPassword);
    changePasswordRequest.setParameter("newPassword1", password);
    changePasswordRequest.setParameter("newPassword2", password);
    response = conversation.getResponse(changePasswordRequest);

    // make sure the change took effect because further tests use test account first log out
    signOutLink = response.getLinkWith("sign out");
    response = conversation.getResponse(signOutLink.getRequest());

    // now check that directed back to the welcome page
    assertEquals("Expecting to retrieve welcome.jsp page.",
        Page.WELCOME.getTitle(), response.getTitle());

    // now attempt to login with the password changed back to test
    assertLogin(conversation, userId, password);
  }

  /**
   * Tests the change password operation with invalid requests such as wrong
   * current password or not match confirm password.
   *
   * @throws Exception If problems occur
   */
  public void testInvalidChangePassword() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";

    // login with the test account
    assertLogin(conversation, userId, password);

    // get the changepassword.jsp page and check for successful retrieval
    WebResponse response = conversation.getResponse(testHost + "sitewatch/changepassword.jsp");
    assertEquals("Expecting changepassword.jsp page.",
        Page.CHANGE_PASSWORD.getTitle(), response.getTitle());

    // attempt to change the password with blank and null fields
    WebForm ChangePasswordForm = response.getFormWithID("ChangePasswordForm");
    WebRequest changePasswordRequest = ChangePasswordForm.getRequest();
    changePasswordRequest.setParameter("password", "");
    // changePasswordRequest.setParameter("newPassword1", ""); // will be null
    changePasswordRequest.setParameter("newPassword2", "");
    response = conversation.getResponse(changePasswordRequest);

    // should have gone back to the changepassword.jsp page
    assertEquals ("Expecting changepassword.jsp page retrieval",
        Page.CHANGE_PASSWORD.getTitle(), response.getTitle());

    // and there should be a message that says to fill in required fields
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting change password error message.", "Invalid password change, please fill "
        + "in all required fields.", messageTable.getCellAsText(0, 0));

    // attempt to change the password to "changed" with an invalid current password
    String newPassword = "changed";
    ChangePasswordForm = response.getFormWithID("ChangePasswordForm");
    changePasswordRequest = ChangePasswordForm.getRequest();
    changePasswordRequest.setParameter("password", "invalid");
    changePasswordRequest.setParameter("newPassword1", newPassword);
    changePasswordRequest.setParameter("newPassword2", newPassword);
    response = conversation.getResponse(changePasswordRequest);

    // should have gone back to the changepassword.jsp page
    assertEquals ("Expecting changepassword.jsp page retrieval",
        Page.CHANGE_PASSWORD.getTitle(), response.getTitle());

    // and there should be a message that says that the password didn't match
    messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting change password error message.", "Your current password is incorrect, "
        + "please check it and try again.", messageTable.getCellAsText(0, 0));

    // now attempt to change the password again, this time with the correct current password but non
    // matching confirmation password
    ChangePasswordForm = response.getFormWithID("ChangePasswordForm");
    changePasswordRequest = ChangePasswordForm.getRequest();
    changePasswordRequest.setParameter("password", password);
    changePasswordRequest.setParameter("newPassword1", newPassword);
    changePasswordRequest.setParameter("newPassword2", "invalid");
    response = conversation.getResponse(changePasswordRequest);

    // should have gone back to the changepassword.jsp page
    assertEquals ("Expecting changepassword.jsp page retrieval",
        Page.CHANGE_PASSWORD.getTitle(), response.getTitle());

    // and there should be a message that says that the new password didn't confirm
    messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting change password error message.",
        "Your new password entries did not match.", messageTable.getCellAsText(0, 0));
  }

}
