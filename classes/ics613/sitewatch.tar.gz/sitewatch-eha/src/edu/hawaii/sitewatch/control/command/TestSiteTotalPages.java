package edu.hawaii.sitewatch.control.command;
import java.util.Hashtable;
import java.util.Iterator;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;
import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests operation of checking total pages for test sites.
 *
 * @author Xiaohua Chen
 * @version $Id: TestSiteTotalPages.java,v 1.8 2003/12/08 20:24:10 xiaohua Exp $
 */
public class TestSiteTotalPages extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the correctness of total page count for site watch application .
   *
   * @throws Exception If problems occur
   */
  public void testTotalTestPages() throws Exception {
    WebConversation conversation = new WebConversation();
    
    // the sites that will be tested along with the corresponding correct total page count
    Hashtable test = new Hashtable ();
    test.put(testHost + "test-sitewatch/one/", "1");
    test.put(testHost + "test-sitewatch/two/", "1");
    test.put(testHost + "test-sitewatch/three/", "2");
    test.put(testHost + "test-sitewatch/four/", "6");
    test.put(testHost + "test-sitewatch/five/", "6");

    String userId = "test";
    String password = "test";

    // getCellAsText removes markup so this will be smashed together
    String columnHeader = "TotalPages";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add each test URL one to five onto the sitewatch and initiate the crawls on them
    for (Iterator i = test.keySet().iterator(); i.hasNext();) {
      String url = (String) i.next();
      response = assertAddSite(conversation, response, url, false);
      response = assertStartCrawl(conversation, response, url);
    }

    // make sure the crawl has time to finish, 5 seconds should be more than enough
    synchronized (this) {
      wait(5000);
    }

    // now refresh to get updated result from crawl
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());

    // and check that we have the expected values
    for (Iterator i = test.keySet().iterator(); i.hasNext();) {
      String url = (String) i.next();
      assertSitesTableValue(response, url, columnHeader, (String) test.get(url));
    }

    //  clean up after ourselves by removing our added URLs
    for (Iterator i = test.keySet().iterator(); i.hasNext(); ) {
      String url = (String) i.next();
      response = assertRemoveSite(conversation, response, url);
    }
  }

}
