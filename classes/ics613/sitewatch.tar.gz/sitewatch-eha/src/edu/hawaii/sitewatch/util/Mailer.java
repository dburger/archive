package edu.hawaii.sitewatch.util;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Provides a simpler interface to the JavaMail API that can be used to send simple email messages.
 *
 * @author David J. Burger
 * @version $Id: Mailer.java,v 1.7 2003/12/04 21:05:09 dburger Exp $
 */
public class Mailer {

  /** The singleton <code>Mailer</code> instance. */
  private static Mailer theInstance = null;

  /** Used to supply properties for the email session. */
  private Properties properties = null;

  /**
   * Private constructor used to create the <code>Properties</code> object and to populate it with
   * the mail host to use for sending.
   */
  private Mailer() {
    this.properties = new Properties();
    this.properties.put("mail.smtp.host",
        ServletUtils.getInstance().getInitParameter("mailHost", null));
  }

  /**
   * Used to retrieve the singleton instance of the <code>Mailer</code>.
   *
   * @return the singleton <code>Mailer</code> instance
   */
  public static synchronized Mailer getInstance() {
    if (Mailer.theInstance == null) {
      Mailer.theInstance = new Mailer();
    }
    return Mailer.theInstance;
  }

  /**
   * Used to send an email with the given from address, to address, subject, and text.
   *
   * @param from the from address for the email
   * @param to the to address for the email
   * @param subject the subject of the email
   * @param text the message text of the email
   * @throws AddressException if the from or to addresses are invalid
   * @throws MessagingException if a problem occurs sending the email
   */
  public void send(String from, String to, String subject, String text) throws AddressException,
      MessagingException {
    Session session = Session.getDefaultInstance(this.properties, null);
    Message message = new MimeMessage(session);
    message.setFrom(new InternetAddress(from));
    message.addRecipient(RecipientType.TO, new InternetAddress(to));
    message.setSubject(subject);
    message.setText(text);
    Transport.send(message);
  }

}