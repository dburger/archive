package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;

/**
 * Implements the Login command.
 *
 * @author Xiaohua Chen
 * @author Fengxian Fan
 * @author David J. Burger
 * @version $Id: LoginCommand.java,v 1.14 2003/12/05 19:07:56 dburger Exp $
 */
public class LoginCommand implements Command {

  /**
   * Processes the "Login" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX on valid login,
   *   Page.WELCOME on invalid login)
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();

    // only changed to Page.INDEX if login validates
    Page returnPage = Page.WELCOME;

    String userId = request.getParameter("userId");
    String password = request.getParameter("password");

    if (userId != null && password != null) {
      SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
      if (accountManager.isValidUser(userId, password)) {
        // the Controller looks for the session attribute userId, if it is found, then the session
        // is a logged in session, thus the following line makes this a logged in session
        session.setAttribute("userId", userId);
        request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
        WebCrawlerManager crawlerManager = WebCrawlerManager.getInstance();
        request.setAttribute("crawlsInProgress", crawlerManager.getUserIdUrls(userId));
        returnPage = Page.INDEX;
      }
      else {
        request.setAttribute("userId", userId);
        request.setAttribute("message",
            "Invaild user name or password, please check and try again.");
        // leave returnPage == Page.WELCOME
      }
    }
    return returnPage;
  }

}
