package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests report of new pages, deleted pages, total pages and modified pages.
 *
 * @author Xiaohua Chen
 * @version $Id: TestSiteReportList.java,v 1.5 2003/12/08 20:24:17 xiaohua Exp $
 */
public class TestSiteReportList extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests each column has valid information.
   *
   * @throws Exception If problems occur
   */
  public void testSiteColumn() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";
    String url1 = "http://csdl.ics.hawaii.edu";
    String url2 = "http://www.ics.hawaii.edu";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add the URL "http://csdl.ics.hawaii.edu onto the sitewatch
    response = assertAddSite(conversation, response, url1, false);

    // now add a second URL into watch
    response = assertAddSite(conversation, response, url2, false);

    // clean up after ourselves by removing our added URLs, the first one
    response = assertRemoveSite(conversation, response, url1);

    // and the second one
    assertRemoveSite(conversation, response, url2);
  }

}
