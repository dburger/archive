package edu.hawaii.sitewatch.model.webcrawler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import edu.hawaii.sitewatch.util.ServletUtils;

/**
 * This singleton class acts as a manager of the <code>WebCrawler</code>
 * threads.  When this class is first instantiated, a number of crawl threads
 * equal to <code>numCrawlThreads</code> will be created.  These crawl
 * threads are started and then immediately call the
 * <code>getRootUrl(WebCrawlerSiteReport)</code> method of this class.  When a
 * crawler calls this method the first time, the parameter will be null, as it
 * has no report to return yet.  The manager will block the crawler thread
 * until a root URL becomes available for it.  When a root URL is available it
 * will be returned to the crawler which will begin the crawling from that root
 * URL.  Upon completion of the crawl the crawler will once again call
 * <code>getRootUrl(WebCrawlerSiteReport)</code>, this time with a valid report
 * object.  This process will continue for the duration of the manager or until
 * the manager calls <code>terminate</code> on the <code>WebCrawler</code>
 * threads.
 * <p />
 *
 * Root URLs are added to this manager via the <code>addRootUrl</code> and
 * <code>addRootURLs</code> calls.  The URLs are placed into three different
 * data structures.  One of them, <code>rootUrlUserIds</code> is used
 * to map root URLs to the user IDs that are waiting on site reports for that
 * root URL.  The next data structure, <code>userIdWorkQueues</code> is
 * used to provide a type of "fair queueing."  The third,
 * <code>userIdRootUrls</code>, keeps track of the root URLs that a given
 * user ID is currently waiting for a site report for.  These data
 * structures are explained further in the paragraphs that follow.
 * <p />
 *
 * The purpose of <code>rootUrlUserIds</code> is to map root URLs to the
 * user IDs that wish to receive a site report about that URL.  This will
 * allow us to prevent crawling the same root URL concurrently.  This is done
 * by checking the map when a root URL is submitted.  If the URL is not found
 * then a mapping is created for it, with the URL as the key and the value a
 * set containing the user ID that submitted the URL.  If the URL is found,
 * that means that the URL is already about to be crawled, so the user ID
 * that submitted the URL is added to the set of user IDs already associated
 * with the URL.  When a crawl finishes, the root URL associated with the crawl
 * is removed from the <code>rootUrlUserIds</code> mapping, and the list of
 * user IDs that became associated with the root URL is included with the
 * <code>WebCrawlerSiteReport</code> that is sent to the
 * <code>WebCrawlerListeners</code>.  In this way the listener can determine
 * which user IDs to associate with the report.
 * <p />
 *
 * The next main data structure of this manager,
 * <code>userIdWorkQueues</code>, attempts to provide a type of
 * "fair queueing" as root URLs are submitted to be crawled.  This is done by
 * keeping a work queue for each user ID that initiates a crawl.  The map of
 * queues is serviced in a least recently accessed fashion.  Thus when a new
 * root URL is submitted for crawling, it goes through the check described in
 * the previous paragraph to see it it represents a new crawl.  If it does not,
 * it is not added to <code>userIdWorkQueues</code>.  If it does represent
 * a new crawl, then a check is first made to see if a work queue already
 * exists for the associated user ID.  If it does, then the new root URL
 * is added to the end of that user ID's work queue.  If it does not, then a
 * new work queue is created for that user ID and hashed into
 * <code>userIdWorkQueues</code>.  When a crawler makes a call to
 * <code>getRootUrl</code> the work queue that has been least recently serviced
 * will be the one selected to provide the next root URL.  The head of its
 * queue will be removed and returned as the next root URL.  If that queue is
 * now empty, it will be removed from the <code>userIdWorkQeueus</code>
 * mapping.  If it is not empty, it has become the most recently
 * accessed and is therefore last in line for future <code>getRootUrl</code>
 * calls.  This least recently accessed behaviour is accomplished by using a
 * <code>LinkedHashMap</code> for <code>userIdWorkQueues</code>.
 * In summary, this queueing procedure will service one root URL from each
 * user ID's work queue in turn.  thus preventing one user ID from
 * hogging all the web crawler threads.
 * <p />
 *
 * The third data structure of this manager, <code>userIdRootUrls</code> is
 * used to keep track of the root URLs that a given user ID is currently
 * waiting on a site report for.  Note that this information is available
 * in <code>rootUrlUserIds</code>, but would require an iteration of the
 * entire map to determine all the root URLs that a particular user ID was
 * currently waiting on site reports for.  This information is not availabe in
 * <code>userIdWorkQueues</code>, as that queue only keeps track of the
 * unique root URLs that a given user ID submitted, and does not list the
 * submitted root URLs that were duplicates of root URLs already in the queue.
 * Thus <code>userIdRootUrls</code> provides a way to get a list of the
 * URLs that a given user ID is waiting on site reports for.  When a crawl
 * finishes the root URL associated with the crawl is removed from the mapping
 * for the user IDs that were waiting on a site report for that root URL.
 * If the mapping for a particular user ID has become empty as a result of
 * this removal, the mapping is removed from <code>userIdRootUrls</code>.
 * <p />
 *
 * Synchronization plays a big role in this class with several of the methods
 * being synchronized.  The purpose of the synchronization is to protect
 * against concurrency problems from simulataneous structural modification
 * of the <code>rootUrlUserIds</code>, <code>userIdWorkQueues</code>,
 * and <code>userIdRootUrls</code> data structures.  These structures are
 * often modified together and these modifications must occur as an atomic
 * unit.
 *
 * @author David J. Burger
 * @version $Id: WebCrawlerManager.java,v 1.3 2003/12/08 06:06:47 dburger Exp $
 */
public class WebCrawlerManager {

  /** The singleton <code>WebCrawlerManager</code> instance. */
  private static WebCrawlerManager theInstance = null;

  /**
   * Used to map root URLs to a set of user IDs interested in the site report
   * of the crawl of that root URL.  This will allow us to avoid crawling from
   * the same root URL concurrently by associating the user ID as a site report
   * recipient with the already queued root URL
   */
  private Map rootUrlUserIds = null;

  /**
   * Used to map user IDs, to a queue of root URLs for that user ID to provide
   * fair queueing.  Fair queueing will be acheived by pulling root URLs from
   * the queues in a least recently accessed fashion.
   */
  private Map userIdWorkQueues = null;

  /**
   * Used to map user IDs to all the URLs that the user ID is waiting on site
   * reports from.
   */
  private Map userIdRootUrls = null;

  /** The limit on the number of pages the crawlers will crawl. */
  private int pageThreshold = 50;

  /** The number of crawler threads that will be created to service crawls. */
  private int numCrawlerThreads = 10;

  /**
   * <code>ArrayList</code> of listeners to be notified of
   * <code>WebCrawlerSiteReport</code>s.
   */
  private ArrayList webCrawlerReportListeners = null;

  /**
   * Creates the data structures and threads used to perform the crawls.
   */
  private WebCrawlerManager() {
    this.rootUrlUserIds = new HashMap();
    // 16, .75F are defaults, third parameter true provide least recently accessed iteration
    this.userIdWorkQueues = new LinkedHashMap(16, .75F, true);
    this.userIdRootUrls = new HashMap();
    retrieveContextParams();
    this.webCrawlerReportListeners = new ArrayList();
    for (int i = 0; i < numCrawlerThreads; i++) {
      new WebCrawler(this.pageThreshold).start();
    }
  }

  /**
   * Used to retrieve the context-params for the Site Watch application that
   * are specific to crawling.
   */
  private void retrieveContextParams() {
    ServletUtils servletUtils = ServletUtils.getInstance();
    this.pageThreshold = servletUtils.getInitParameter("pageThreshold", 500);
    this.numCrawlerThreads = servletUtils.getInitParameter("numCrawlerThreads", 20);
  }

  /**
   * Used to retrieve the singleton instance of the
   * <code>WebCrawlerManger</code>.
   *
   * @return the singleton instance of the <code>WebCrawlerManger</code>
   */
  public static synchronized WebCrawlerManager getInstance() {
    if (WebCrawlerManager.theInstance == null) {
      WebCrawlerManager.theInstance = new WebCrawlerManager();
    }
    return WebCrawlerManager.theInstance;
  }

  /**
   * Used by a threaded <code>WebCrawler</code> to both return the site report
   * of a finished crawl and to get another root URL to work on.  On the first
   * call to this method the <code>WebCrawler</code> will have no report to
   * return and therefore will pass in null.  If there are no root URLs
   * available the crawler thread will be blocked until a root URL is
   * is available for that thread.  When a root URL is available it will be
   * selected from the work queues in a least recently accessed fashion and
   * will be returned to the crawler.  On subsequent calls to this method the
   * crawler will pass in a valid <code>WebCrawlerSiteReport</code>.  This
   * report will be forwarded to the listeners.
   *
   * @param siteReport the <code>WebCrawlerSiteReport</code> of a finished
   *     crawl or null, if this is the first call by the
   *     <code>WebCrawler</code>
   * @return the next available root URL, blocking until there is one
   */
  public synchronized String getRootUrl(WebCrawlerSiteReport siteReport) {
    if (siteReport != null) {
      // get the set of user IDs that submitted this root URL
      Set userIds = (Set) this.rootUrlUserIds.remove(siteReport.getRootUrl());
      // remove this root URL from the set of URLs that each user ID is waiting on
      for (Iterator i = userIds.iterator(); i.hasNext();) {
        String userId = (String) i.next();
        Set urls = (Set) this.userIdRootUrls.get(userId);
        if (urls != null) {
          urls.remove(siteReport.getRootUrl());
          // if the user ID has no more associated URLs, remove it
          if (urls.size() == 0) {
            this.userIdRootUrls.remove(userId);
          }
        }
      }
      notifyWebCrawlerListeners(siteReport, (String[]) userIds.toArray(new String[] {}));
    }

    // wait for a root URL
    while (this.userIdWorkQueues.size() <= 0) {
      try {
        wait();
      }
      catch (InterruptedException e) {
        // loop back and check the size again
      }
    }

    // size is greater than 0, get the next root URL the usage of the LinkedHashMap insures this
    // root URL to be from the least recently accessed queue
    String userId = (String) this.userIdWorkQueues.keySet().iterator().next();
    List workQueue = (List) this.userIdWorkQueues.get(userId);
    String rootUrl = (String) workQueue.remove(0);
    if (workQueue.size() == 0) {
      this.userIdWorkQueues.remove(userId);
    }
    return rootUrl;
  }

  /**
   * Used to retrieve an array of URLs that the given user ID is currently
   * waiting on a site report for.  Note that we do not return the Map directly
   * as it could lead to a concurrent modification exception.
   *
   * @param userId the userId to retrieve the URLs for
   * @return array of URLs the given user ID is waiting on a site report for
   */
  public synchronized String[] getUserIdUrls(String userId) {
    Set urls = (Set) this.userIdRootUrls.get(userId);
    if (urls != null) {
      return (String[]) urls.toArray(new String[0]);
    }
    else {
      return new String[0];
    }
  }

  /**
   * Submits the given root URL for crawling.  The root URL will be added to
   * <code>userIdWorkQueues</code> if the URL is not already in the queue.
   * The user ID will be added to the set of user IDs waiting on a site
   * report for the root URL in <code>rootUrlUserIds</code>.  The root URL
   * will be added to the set of root URLs that the given user ID is waiting
   * on site reports for in <code>userIdRootUrls</code>.
   *
   * @param userId the user ID to add a root URL for
   * @param rootUrl the root URL to add
   */
  public synchronized void addRootUrl(String userId, String rootUrl) {
    // first we make sure this URL is associated with this user ID so that crawls in progress
    // information can be supplied
    Set urls = (Set) this.userIdRootUrls.get(userId);
    if (urls == null) {
      // a mapping doesn't exist, make one for this user ID, using TreeSet to get a sorted view
      urls = new TreeSet();
      this.userIdRootUrls.put(userId, urls);
    }
    // add rootUrl to user ID's mapping
    urls.add(rootUrl);
    // see if this root URL is already in the queue for crawling
    Set userIds = (Set) this.rootUrlUserIds.get(rootUrl);
    if (userIds != null) {
      // root URL already in queue, add user ID as report recipient
      userIds.add(userId);
    }
    else {
      // the root URL isn't in the queue, make a set to hold the interested user IDs
      userIds = new HashSet();
      userIds.add(userId);
      this.rootUrlUserIds.put(rootUrl, userIds);
      // and add it to the work queues, first check if this user ID is already associated with a
      // work queue
      List workQueue = (List) this.userIdWorkQueues.get(userId);
      if (workQueue == null) {
        // this user ID doesn't have a work queue, make one
        workQueue = new LinkedList();
        this.userIdWorkQueues.put(userId, workQueue);
      }
      workQueue.add(rootUrl);
      // notify one sleeping crawler that there are root URLs in the queue
      notify();
    }
  }

  /**
   * Submits the given root URLs for crawling.  A root URL will be added to
   * <code>userIdWorkQueues</code> if the URL is not already in the queue.
   * The user ID will be added to the set of user IDs waiting on a site
   * report for the root URLs in <code>rootUrlUserIds</code>.  The root
   * URLs will be added to the set of root URLs that the given user ID is
   * waiting on site reports for in <code>userIdRootUrls</code>.
   *
   * @param userId the user ID to add the root URLs for
   * @param rootUrls the array of root URLs to add
   */
  public synchronized void addRootUrls(String userId, String[] rootUrls) {
    for (int i = 0; i < rootUrls.length; i++) {
      // first we make sure this URL is associated with this user ID so that crawls in progress
      // information can be supplied
      Set urls = (Set) this.userIdRootUrls.get(userId);
      if (urls == null) {
        // a mapping doesn't exist, make one for this user ID, using TreeSet to get a sorted view
        urls = new TreeSet();
        this.userIdRootUrls.put(userId, urls);
      }
      // add rootUrls[i] to user ID's mapping
      urls.add(rootUrls[i]);
      // see if rootUrls[i] is already in the queue for crawling
      Set userIds = (Set) this.rootUrlUserIds.get(rootUrls[i]);
      if (userIds != null) {
        // rootUrls[i] already in queue, add user ID as report recipient
        userIds.add(userId);
      }
      else {
        // rootUrls[i] isn't in the queue, make a set to hold the interested
        // user IDs
        userIds = new HashSet();
        userIds.add(userId);
        this.rootUrlUserIds.put(rootUrls[i], userIds);
        // and add it to the work queues, first check if this user ID is already associated with a
        // work queue
        List workQueue = (List) this.userIdWorkQueues.get(userId);
        if (workQueue == null) {
          // this user ID doesn't have a work queue, make one
          workQueue = new LinkedList();
          this.userIdWorkQueues.put(userId, workQueue);
        }
        workQueue.add(rootUrls[i]);
        // notify sleeping crawlers that there are root URLs in the queue
        if (rootUrls.length == 1) {
          notify();
        }
        else {
          notifyAll();
        }
      }
    }
  }

  /**
   * Adds a <code>WebCrawlerListener</code> to the list of listeners
   * that will be notified with a <code>WebCrawlerSiteReport</code> upon crawl
   * completion.
   *
   * @param listener the listener to add
   */
  public void addWebCrawlerListener(WebCrawlerListener listener) {
    this.webCrawlerReportListeners.add(listener);
  }

  /**
   * Notifies the list of <code>WebCrawlerListener</code>s of a
   * <code>WebCrawlerSiteReport</code>.
   *
   * @param siteReport the <code>WebCrawlerSiteReport</code> to send to the
   *     listeners
   * @param userIds array of user IDs associated with the report
   */
  private void notifyWebCrawlerListeners(WebCrawlerSiteReport siteReport,
      String[] userIds) {
    // a copy must be made in the case a listener removes itself as a result of this callback
    Iterator i = new ArrayList(this.webCrawlerReportListeners).iterator();
    while (i.hasNext()) {
      WebCrawlerListener listener = (WebCrawlerListener) i.next();
      listener.webCrawlerFinished(siteReport, userIds);
    }
  }

}
