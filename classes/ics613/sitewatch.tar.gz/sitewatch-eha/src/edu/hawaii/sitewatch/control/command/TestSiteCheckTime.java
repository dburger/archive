package edu.hawaii.sitewatch.control.command;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests lastCheck field.
 *
 * @author Xiaohua Chen
 * @version $Id: TestSiteCheckTime.java,v 1.6 2003/12/08 20:24:31 xiaohua Exp $
 */
public class TestSiteCheckTime extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests lastCheck field contains time format.
   *
   * @throws Exception If problems occur
   */
  public void testLastCheck() throws Exception {
    WebConversation conversation = new WebConversation();

    final String REGEX = "([0-9]{1,2})/([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2})";

    String url = "http://www2.hawaii.edu/~xiaohua/ta/";

    // getCellAsText removes markup so this will be smashed together
    String columnHeader = "LastCheck";

    String userId = "test";
    String password = "test";

    // login with the testcrawler account
    WebResponse response = assertLogin(conversation, userId, password);

    // add the URL test URL one to five onto the sitewatch
    response = assertAddSite(conversation, response, url, false);

    // now crawl the url
    response = assertStartCrawl(conversation, response, url);

    // make sure the crawl has time to finish, 5 seconds should be enough
    synchronized (this) {
      wait(5000);
    }

    // now refresh to get updated result from crawl
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());

    // and check that we have a date value
    WebTable sitesTable = response.getTableWithID("sitesTable");
    String checkTime = sitesTable.getCellAsText(1, 3);
    Pattern p = Pattern.compile(REGEX);
    Matcher m = p.matcher(checkTime);
    assertTrue("checking LastCheck contains mm/dd hh:mm", m.matches());

    //  clean up after ourselves by removing our added URL
    assertRemoveSite(conversation, response, url);
  }

}
