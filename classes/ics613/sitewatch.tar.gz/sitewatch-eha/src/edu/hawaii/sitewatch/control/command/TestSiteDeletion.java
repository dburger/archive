package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Test operation of the Remove command.
 *
 * @author Fengxian Fan
 * @author David J. Burger (did minor changes)
 * @version $Id: TestSiteDeletion.java,v 1.9 2003/12/06 22:15:28 dburger Exp $
 */
public class TestSiteDeletion extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the SiteWatch Remove operation under normal situation.
   *
   * @throws Exception when errors occur
   */
  public void testRemove() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";
    String url = "http://csdl.ics.hawaii.edu";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add the url onto the sitewatch
    response = assertAddSite(conversation, response, url, false);

    // remove the site from the sites list Table
    assertRemoveSite(conversation, response, url);
  }

}
