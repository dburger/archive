package edu.hawaii.sitewatch.util;

import junit.framework.TestCase;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;

/**
 * Provides an abstract base class that has a methods commonly used in the
 * unit tests for the site watch application.
 *
 * @author David J. Burger
 * @version $Id: SiteWatchTestCase.java,v 1.4 2003/12/08 06:06:47 dburger Exp $
 */
public abstract class SiteWatchTestCase extends TestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Used to assert logging in to the site watch application, returning the
   * <code>WebResponse</code> that is the result of the login.
   *
   * @param conversation the <code>WebConversation</code> to use to fetch
   *     the login form
   * @param userId the user ID to use for the login
   * @param password the password to use for the login
   * @return the response of the successful login, if not successful, the
   *     assertions will fail
   * @throws Exception if a problem occurs
   */
  public WebResponse assertLogin(WebConversation conversation, String userId,
      String password) throws Exception {

    // get welcome.jsp page and check for successful retrieval
    WebResponse response = conversation.getResponse(testHost + "sitewatch/welcome.jsp");
    assertEquals("Expecting welcome.jsp page.", Page.WELCOME.getTitle(), response.getTitle());

    // look for the login form in the response
    WebForm loginForm = response.getFormWithID("LoginForm");
    assertNotNull("Expecting to find the login form.", loginForm);

    // now attempt to login
    WebRequest loginRequest = loginForm.getRequest();
    loginRequest.setParameter("userId", userId);
    loginRequest.setParameter("password", password);
    response = conversation.getResponse(loginRequest);

    // should have the main display page, index.jsp
    assertEquals ("Expecting index.jsp page retrieval", Page.INDEX.getTitle(), response.getTitle());

    return response;
  }

  /**
   * Used to assert values in the sitesTable of the main display page.  The
   * cell to assert against is located by the passed in row and column
   * headers.  This method will cause a unit test to fail if the row or column
   * can't be found, or if the value found in the specified row and column
   * doesn't match the expected value.
   *
   * @param response the <code>WebResponse</code> to locate the table in
   *     and assert the value on
   * @param rowHeader the header of the row to assert the result against
   * @param columnHeader the header of the column to assert the result against
   * @param expectedValue the expected value in this row, column
   * @throws Exception if any problem occurs during this method
   */
  public void assertSitesTableValue(WebResponse response, String rowHeader,
      String columnHeader, String expectedValue) throws Exception {

    // locate the table
    WebTable sitesTable = response.getTableWithID("sitesTable");
    assertNotNull("Expecting to find sitesTable.", sitesTable);

    // locate the column corresponding to columnHeader
    int column = 0;
    for (; column < sitesTable.getColumnCount(); column++) {
      if (sitesTable.getCellAsText(0, column).equals(columnHeader)) {
        break;
      }
    }
    assertTrue("Expected to find the column header " + columnHeader + ".",
        (column < sitesTable.getColumnCount()));

    // locate the row corresponding to rowHeader
    int row = 0;
    for (; row < sitesTable.getRowCount(); row++) {
      if (sitesTable.getCellAsText(row, 1).equals(rowHeader)) {
        break;
      }
    }
    assertTrue("Expected to find the row header " + rowHeader + ".",
      row < sitesTable.getRowCount());

    // finally assert the expected value against the actuall value
    assertEquals("Expected to find the value " + expectedValue + " for row " + rowHeader + " and "
        + "column " + columnHeader + ".", expectedValue, sitesTable.getCellAsText(row, column));
  }

  /**
   * Used to assert the addtion of a site URL to main display page in the Site
   * Watch application.  This method will cause a unit test to fail if the
   * addForm can't be found or the URL can't be added to the watch list.
   *
   * @param conversation the <code>WebConversation</code> to use to submit the
   *     add request
   * @param response the <code>WebResponse</code> that holds the addForm
   * @param url the URL of the site to add to the watch list
   * @param emailAlerts true if the given site should fire email alerts on changes,
   *     false otherwise
   * @return the <code>WebResponse</code> of the successful addition, if not
   *     successful the assertions will fail
   * @throws Exception if any problem occurs during this method
   */
  public WebResponse assertAddSite(WebConversation conversation, WebResponse response,
      String url, boolean emailAlerts) throws Exception {

    // first locate the sitesTable to get a before row count
    int beforeRowCount = 3;
    WebTable sitesTable = response.getTableWithID("sitesTable");
    if (sitesTable != null) {
      beforeRowCount = sitesTable.getRowCount();
    }

    // locate the addForm
    WebForm addForm = response.getFormWithID("AddSiteForm");
    assertNotNull("Expected to have found the addForm.", addForm);

    WebRequest addRequest = addForm.getRequest();
    addRequest.setParameter("newSite", url);
    if (emailAlerts) {
      addRequest.setParameter("emailAlerts", "emailAlerts");
    }
    response = conversation.getResponse(addRequest);

    // locate the sitesTable
    sitesTable = response.getTableWithID("sitesTable");
    assertNotNull("Excpecting to have found the sitesTable.", sitesTable);

    // make sure the row count has increased by one
    assertEquals("Expecting the row count to have increased by one.", beforeRowCount + 1,
        sitesTable.getRowCount());

    return response;
  }

  /**
   * Used to assert the remoal of a site URL from main display page in the Site
   * Watch application.  This method will cause a unit test to fail if the
   * DisplaySitesForm can't be found or the URL can't be removed from the watch
   * list.
   *
   * @param conversation the <code>WebConversation</code> to use to submit the
   *     remove
   * @param response the <code>WebResponse</code> that holds the DisplaySitesForm
   * @param url the URL of the site to remove to the watch list
   * @return the <code>WebResponse</code> of the successful removal, if not
   *     successful the assertions will fail
   * @throws Exception if any problem occurs during this method
   */
  public WebResponse assertRemoveSite(WebConversation conversation, WebResponse response,
      String url) throws Exception {

    // locate the sitesTable and get a before row count
    WebTable sitesTable = response.getTableWithID("sitesTable");
    assertNotNull("Expected to have found the sitesTable.", sitesTable);
    int beforeRowCount = sitesTable.getRowCount();

    // locate the DisplaySitesForm within the response
    WebForm displayForm = response.getFormWithID("DisplaySitesForm");
    assertNotNull("Expected to have found the DisplaySitesForm.", displayForm);

    // submit the URL for removal
    WebRequest removeRequest = displayForm.getRequest(displayForm.getSubmitButtonWithID("Remove"));
    removeRequest.setParameter("site", url);
    response = conversation.getResponse(removeRequest);

    // check that the sites table has one less row
    sitesTable = response.getTableWithID("sitesTable");
    if (beforeRowCount == 4) {
      assertNull("Expecting the sitesTable to have been removed.", sitesTable);
    }
    else {
      assertEquals("Expecting the row count to have decreased by one.", beforeRowCount - 1,
          sitesTable.getRowCount());
    }

    return response;
  }

  /**
   * Used to start a crawl from the main display page on the given url.  This
   * method will cause a unit test to fail if the DisplaySitesForm can't be
   * found or if the given url actually wasn't in the form.
   *
   * @param conversation the <code>WebConversation</code> to use to submit the
   *     crawl request
   * @param response the <code>WebResponse</code> that holds the DisplaySitesForm
   * @param url the URL of the site to crawl
   * @return the <code>WebResponse</code> of the successful crawl request, if not
   *     successful the assertions will fail
   * @throws Exception if any problem occurs during this method
   */
  public WebResponse assertStartCrawl(WebConversation conversation, WebResponse response,
      String url) throws Exception {

    // find the display form
    WebForm displayForm = response.getFormWithID("DisplaySitesForm");
    assertNotNull("Excpected to find the DisplaySitesForm.", displayForm);

    // submit a request to crawl the url
    WebRequest checkRequest = displayForm.getRequest(displayForm.getSubmitButtonWithID("Check"));
    checkRequest.setParameter("site", url);
    return conversation.getResponse(checkRequest);      
  }

}
