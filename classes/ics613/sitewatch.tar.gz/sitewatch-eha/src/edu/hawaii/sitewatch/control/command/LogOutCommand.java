package edu.hawaii.sitewatch.control.command;
import javax.servlet.http.HttpServletRequest;
import edu.hawaii.sitewatch.control.Page;

/**
 * Implements the LogOut ccommand.
 *
 * @author David J. Burger
 * @version $Id: LogOutCommand.java,v 1.4 2003/12/04 20:43:10 dburger Exp $
 */
public class LogOutCommand implements Command {

  /**
   * Processes the "LogOut" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.WELCOME)
   */
  public Page process(HttpServletRequest request) {
    request.getSession().invalidate();
    request.setAttribute("message", "Goodbye, thank you for using Site Watch!");
    return Page.WELCOME;
  }

}
