package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests the application's ability of setting custom email notification settings.
 *
 * @author Fengxian Fan
 * @version $Id: TestCustomUserEmailNotification.java,v 1.4 2003/12/08 20:25:02 xiaohua Exp $
 */
public class TestCustomUserEmailNotification extends SiteWatchTestCase {

  /**
   * Tests the application's ability to let the user set or change
   * email notification setting before crawlering
   *
   * @throws Exception if problems occur
   */
  public void testCustomerUserEmailNotificatin() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";
    String url1 = "http://csdl.ics.hawaii.edu";
    String url2 = "http://www.ics.hawaii.edu";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add the URL http://csdl.ics.hawaii.edu onto the sitewatch
    response = assertAddSite(conversation, response, url1, true);

    // make sure the URL's email alert setting says "Yes"
    assertSitesTableValue(response, url1, "EmailAlerts",  "Yes");

    //add the second URL http://ics.hawaii.edu onto the sitewatch
    response = assertAddSite(conversation, response, url2, false);

    // make sure the URL's email alert setting says "No"
    assertSitesTableValue(response, url2, "EmailAlerts", "No");

    // retrieve the email setting page
    WebLink emailSettingLink = response.getLinkWith("email settings");
    response = conversation.getResponse(emailSettingLink.getRequest());
    assertEquals("Expecting to retrieve emailsetting.jsp page.",
        Page.EMAIL_SETTINGS.getTitle(), response.getTitle());

    //  locate the sitesTable
    WebTable table = response.getTableWithID("sitesTable");
    assertNotNull("Expecting to find table with ID sitesTable", table);

    // now change the email notification settings, first URL no, second yes
    WebForm emailSettingsForm = response.getFormWithID("EmailSettingsForm");
    emailSettingsForm.setParameter("site", url2);
    response = conversation.getResponse(emailSettingsForm.getRequest());

    //now check that directed to index.jsp page
    assertEquals("Expected the retrieval of index.jsp page",
        Page.INDEX.getTitle(), response.getTitle());

    //check the alert email settings have been changed
    assertSitesTableValue(response, url1, "EmailAlerts",  "No");
    assertSitesTableValue(response, url2, "EmailAlerts", "Yes");

    //  clean up after ourselves by removing our added URLs, the first one
    response = assertRemoveSite(conversation, response, url1);

    // and the second one
    assertRemoveSite(conversation, response, url2);
  }
}
