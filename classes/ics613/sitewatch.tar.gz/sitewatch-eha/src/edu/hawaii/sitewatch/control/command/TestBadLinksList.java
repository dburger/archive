package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;
/**
 * Tests operation of checking bad link pages for testing sites.
 *
 * @author Xiaohua Chen
 * @version $Id: TestBadLinksList.java,v 1.5 2003/12/08 20:25:07 xiaohua Exp $
 */
public class TestBadLinksList extends SiteWatchTestCase {
  /** Get the test host. */
  private String testHost = System.getProperty("test.host");
  /**
   * Tests the list of bad links.
   *
   * @throws Exception If problems occur
   */
  public void testBadLinks() throws Exception {
    String url = testHost + "test-sitewatch/badlinks/";
    String [] expected = {
      testHost + "test-sitewatch/badlinks/", "badlink1.html",
      testHost + "test-sitewatch/badlinks/", "badlink2.html",
      testHost + "test-sitewatch/badlinks/", "badlink3.html",
      testHost + "test-sitewatch/badlinks/dir1/", "../badlink4.html",
      testHost + "test-sitewatch/badlinks/dir1/one.html", "badlink.html",
      testHost + "test-sitewatch/badlinks/dir3/dir1/", "badlink.html",
    };

    // login with the testcrawler account
    WebConversation conversation = new WebConversation();
    String userId = "test";
    String password = "test";
    WebResponse response = assertLogin(conversation, userId, password);

    // add the testing URL onto the sitewatch
    response = assertAddSite(conversation, response, url, false);

    // now check the URL
    response = assertStartCrawl(conversation, response, url);

    // make sure the crawl has time to finish, 5 seconds should be enough
    synchronized (this) {
      wait(5000);
    }
    // now refresh to get updated result from crawl, expecting index.jsp.
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());
    // get link of bad link by linkID to get badlinks.jsp
    WebLink blLink = response.getLinkWithID("badLinkID");
    response = blLink.click();
    assertEquals("Expecting badlinks.jsp page.", Page.BAD_LINKS.getTitle(), response.getTitle());

    // check listed badLinks are bad links.
    WebTable blTable = response.getTableWithID("badLinksTable");
    assertEquals("Expecting 8 rows.", blTable.getRowCount(), 8);
    int j = 0;
    for (int i = 2; i < blTable.getRowCount(); i++) {
      String page = blTable.getCellAsText(i, 0);
      String link = blTable.getCellAsText(i, 1);
      assertEquals("checking cell matching pageURL", page, expected[j]);
      assertEquals("checking cell matching link", link, expected[++j]);
      j++;
    }

    //  clean up after ourselves by removing our added URL
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());
    assertRemoveSite(conversation, response, url);
  }

}
