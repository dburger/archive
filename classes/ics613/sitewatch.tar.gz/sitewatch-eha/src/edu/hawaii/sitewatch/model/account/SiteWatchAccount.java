package edu.hawaii.sitewatch.model.account;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import edu.hawaii.sitewatch.util.Mailer;
import edu.hawaii.sitewatch.util.ServletUtils;
import edu.hawaii.sitewatch.model.site.WatchedPageReport;
import edu.hawaii.sitewatch.model.site.WatchedSite;
import edu.hawaii.sitewatch.model.site.WatchedSiteReport;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerSiteReport;

/**
 * Represents a users site watch account.
 *
 * @author David J. Burger
 * @author Fengxian Fan (enable to check new, deleted, modified pages)
 * @author Xiaohua Chen (enable to check new pages, and so on)
 * @version $Id: SiteWatchAccount.java,v 1.3 2003/12/08 06:06:47 dburger Exp $
 */
public class SiteWatchAccount implements Serializable {

  /** The unique user ID of this account. */
  private String userId = null;

  /** The email address of this account. */
  private String emailAddress = null;

  /** The password of this account. */
  private String password = null;

  /**
   * The map of sites that are watched for this account.  The mapping will
   * map the root url to a <code>WatchedSite</code> which contains the
   * information of the site including url, email alert flag, and a report on
   * crewlering results.  If the report in the <code>WatchedSite</code> is null
   *  then a crawl hasn't been executed for the site yet.
   */
  private Map watchedSites = null;

  /**
   * Constructor that creates a user account with the given id, first name,
   * last name, email address, and password as well as creating the
   * <code>watchedSites</code> <code>Map</code>.
   *
   * @param userId the user ID for this account
   * @param emailAddress the email address for this account
   * @param password the password for this account
   */
  public SiteWatchAccount(String userId, String emailAddress, String password) {
    this.watchedSites = new TreeMap();
    this.userId = userId;
    this.emailAddress = emailAddress;
    this.password = password;
  }

  /**
   * Returns the email address for this account.
   *
   * @return the email address for this account
   */
  public String getEmailAddress() {
    return this.emailAddress;
  }

  /**
   * Returns the password for this account.
   *
   * @return the password for this account
   */
  public String getPassword() {
    return this.password;
  }

  /**
   * Sets the password for this account.
   *
   * @param password the password for this account
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * Returns the user ID for this account.
   *
   * @return the user ID for this account
   */
  public String getUserId() {
    return this.userId;
  }

  /**
   * Adds the given root URL to the list of URLs watched for this account if
   * it isn't already in the list.
   *
   * @param rootUrl the root URL to add to the watched list
   * @param triggersEmail the flag marking if site report changes need to be
   *     emailed to the user when changes occur in the site report
   * @throws SiteWatchAccountException if this add would result in more sites in the watch list
   *     than that allowed by the siteThreshold value
   */
  public void addSite(String rootUrl, boolean triggersEmail) throws SiteWatchAccountException {
    if (!this.watchedSites.containsKey(rootUrl)) {
      int siteThreshold = ServletUtils.getInstance().getInitParameter("siteThreshold", 50);
      if (this.watchedSites.size() >= siteThreshold) {
        throw new SiteWatchAccountException("You have reached the site threshold limit.  You will "
            + "be unable to add " + rootUrl + " unless you remove a site.");
      }
      this.watchedSites.put(rootUrl, new WatchedSite(rootUrl, triggersEmail, null));
    }
  }

  /**
   * Removes the given URL from the list of URLs to be watched for this
   * account.
   *
   * @param rootUrl the root URL to remove from the watched list
   */
  public void removeSite(String rootUrl) {
    this.watchedSites.remove(rootUrl);
  }

  /**
   * Iterates through the passed in array of URLs, removing them from the
   * list of URLs that are to be watched for this account.
   *
   * @param rootUrls array of root URLs to remove from the watched list
   */
  public void removeSites(String[] rootUrls) {
    for (int i = 0; i < rootUrls.length; i++) {
      removeSite(rootUrls[i]);
    }
  }

  /**
   * Modifieds the email alert settings for this account so only those in the
   * passed in array <code>sites</code> are true.
   *
   * @param sites array of sites whose email alert setting should be true
   */
  public void modifyEmailSettings(String[] sites) {
    // change all to false
    for (Iterator i = this.watchedSites.values().iterator(); i.hasNext();) {
      WatchedSite watchedSite = (WatchedSite) i.next();
      watchedSite.setTriggersEmail(false);
    }
    // change the ones found in sites to true
    for (int i = 0; i < sites.length; i++) {
      WatchedSite watchedSite = (WatchedSite) this.watchedSites.get(sites[i]);
      if (watchedSite != null) {
        watchedSite.setTriggersEmail(true);
      }
    }
  }

  /**
   * Creates and returns a new <code>WatchedSiteReport</code> through a
   * comparison of a new <code>WebCrawlerSiteReport</code> against an existing
   * <code>WatchedSiteReport</code>.  It may be that there is no existing
   * report, in which case the computation of the new report is relatively
   * simple, that is all pages are new, none are modified, and none are
   * deleted.  In the case that there is an existing report, a typical two
   * sorted list comparison is made to determine new and deleted pages, with
   * modified determined by comparing the last modified dates of matching
   * URLs.
   *
   * @param crawlerReport a <code>WebCrawlerSiteReport</code> from the crawler
   * @param oldReport the existing report for the same site that the crawler's
   *     report represents, or null if there is no such report
   * @return a newly created <code>WatchedSiteReport</code>
   */
  private WatchedSiteReport createWatchedSiteReport(WebCrawlerSiteReport crawlerReport,
      WatchedSiteReport oldReport) {
    int newPageCount, modifiedPageCount, deletedPageCount;
    newPageCount = modifiedPageCount = deletedPageCount = 0;
    if (oldReport == null) {
      // there is no old report to compare the new report against, all pages are new, none are
      // modified or deleted
      newPageCount = crawlerReport.getPageCount();
    }
    else {
      WatchedPageReport[] crawlerPages = crawlerReport.getWatchedPageReports();
      WatchedPageReport[] reportPages = oldReport.getWatchedPageReports();
      int i = 0; // will be used to index on crawlerPages
      int j = 0; // will be used to index on reportPages
      // loop until one of the arrays is exhausted
      while (i < crawlerPages.length && j < reportPages.length) {
        String crawlerUrl = crawlerPages[i].getUrl();
        String reportUrl = reportPages[j].getUrl();
        int compareResult = crawlerUrl.compareTo(reportUrl);
        if (compareResult < 0) {
          // crawlerPages[i] is new
          newPageCount++;
          i++;
        }
        else if (compareResult == 0) {
          // in both lists, compare last modified to see if changed
          if (crawlerPages[i].getLastModified() > reportPages[j].getLastModified()) {
            modifiedPageCount++;
          }
          i++;
          j++;
        }
        else {
          // reportPages[j] has been deleted
          deletedPageCount++;
          j++;
        }
      }
      // at least one of the arrays is now exhausted
      if (i < crawlerPages.length) {
        // all the remaining urls are new
        newPageCount += (crawlerPages.length - i);
      }
      if (j < reportPages.length) {
        // all the remaining urls have been deleted
        deletedPageCount += (reportPages.length - j);
      }
    }
    return new WatchedSiteReport(newPageCount, deletedPageCount,
        modifiedPageCount, crawlerReport.getBadLinkCount(), crawlerReport.getWatchedPageReports());
  }

  /**
   * Accepts a <code>WebCrawlerSiteReport</code> and updates the associated
   * <code>WatchedSiteReport</code>.
   *
   * @param siteReport the <code>WebCrawlerSiteReport</code> from a completed
   *     crawl
   */
  public void updateSiteReport(WebCrawlerSiteReport siteReport) {
    String rootUrl = siteReport.getRootUrl();
    if (!this.watchedSites.containsKey(rootUrl)) {
      // watched site removed before spider finished, just return
      return;
    }
    WatchedSite watchedSite = (WatchedSite) this.watchedSites.get(rootUrl);
    WatchedSiteReport oldReport = watchedSite.getSiteReport();
    WatchedSiteReport newReport = createWatchedSiteReport(siteReport, oldReport);
    watchedSite.setSiteReport(newReport);
    if (watchedSite.getTriggersEmail() && (newReport.getNewPageCount() > 0
        || newReport.getModifiedPageCount() > 0 || newReport.getModifiedPageCount() > 0)) {
      ServletUtils servletUtils = ServletUtils.getInstance();
      String fromAddress = servletUtils.getInitParameter("fromAddress", "sitewatch@sitewatch.com");
      try {
        Mailer.getInstance().send(fromAddress, this.getEmailAddress(), "Site Watch email alert",
            "Site Watch has detected changes to your watched site " + rootUrl + ".  Please login to"
            + " Site Watch to view the changes.");
      }
      catch (Exception e) {
        // MessagingException, AddressException
        servletUtils.log("A " + e.getClass().getName() + " occurred while sending an email alert: "
            + e.getMessage(), e);
      }
    }
  }

  /**
   * Returns an array containing the <code>WatchedSite</code>s being watched
   * by this user.
   *
   * @return array of sites being watched by this user
   */
  public WatchedSite[] getWatchedSites() {
    return (WatchedSite[]) this.watchedSites.values().toArray(new WatchedSite[0]);
  }

  /**
   * Returnst the <code>WatchedSiteReport</code> for the site indicated by
   * the URL <code>url</code> or null if there is no such site report.
   *
   * @param url the URL of the site to return the site report of
   * @return the associated site report or null if it can't be found
   */
  public WatchedSite getWatchedSite(String url) {
    return (WatchedSite) this.watchedSites.get(url);
  }

  /**
   * Used to start the crawling of every root URL for this account.
   */
  public void startAutomaticCrawl() {
    if (this.watchedSites.size() > 0) {
      WebCrawlerManager manager = WebCrawlerManager.getInstance();
      manager.addRootUrls(this.userId,
          (String[]) this.watchedSites.keySet().toArray(new String[0]));
    }
  }

  /**
   * Loads and returns the <code>SiteWatchAccount</code> for the user with the
   * given user ID, or null if the account can't be found or a problem occurs.
   *
   * @param userId the user ID of the account to load
   * @return the <code>SiteWatchAccount</code> for the given user, or null if
   *     the account can't be found or a problem occurs
   */
  public static SiteWatchAccount load(String userId) {
    ServletUtils servletUtils = ServletUtils.getInstance();
    String dataPath = servletUtils.getInitParameter("dataPath", "/WEB-INF/db/");
    dataPath = servletUtils.getRealPath(dataPath);
    File file = new File(dataPath + "/" + userId);
    SiteWatchAccount account = null;
    try {
      ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
      account = (SiteWatchAccount) in.readObject();
    }
    catch (Exception e) {
      // ClassCastException, FileNotFoundException, IOException, leave account == null
    }
    return account;
  }

  /**
   * Saves this <code>SiteWatchAccount</code> for later retrieval, indexed by
   * user ID.
   *
   * @throws IOException if a problem occurs while saving this account
   */
  public void save() throws IOException {
    ServletUtils servletUtils = ServletUtils.getInstance();
    String dataPath = servletUtils.getInitParameter("dataPath", "/WEB-INF/db/");
    dataPath = servletUtils.getRealPath(dataPath);
    new File(dataPath).mkdirs();
    File file = new File(dataPath + "/" + getUserId());
    ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
    out.writeObject(this);
    out.close();
  }

}
