﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using EARTHLib;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Xml;

namespace GooHelloWorld {

    public partial class GooHelloWorld : Form {

        private const String USERNAME = "admin";
        private const String PASSWORD = "letmein";
        private const String BASE_URL = "https://dev.goo.camberhawaii.org";

        private String _appPath = null;
        private ApplicationGEClass _geApp = null;
        private HttpBasic _httpBasic;

        public GooHelloWorld() {
            InitializeComponent();
        }

        private void btnLoadKml_Click(object sender, EventArgs e) {
            String kml = rtxtKml.Text;
            _geApp.LoadKmlData(ref kml);
        }

        private void GooHelloWorld_Load(object sender, EventArgs e) {
            _appPath = getAppPath();
            _geApp = new ApplicationGEClass();
            while (_geApp.IsInitialized() == 0) Thread.Sleep(5);
            WinApi.SetParent(_geApp.GetMainHwnd(), (int)pnlGoogleEarth.Handle);
            sizeGoogleEarth();
            // doesn't like our certificate so must disable client side check
            ServicePointManager.CertificatePolicy = new AcceptAllCertificatePolicy();
            _httpBasic = new HttpBasic(USERNAME, PASSWORD, BASE_URL);
            loadIconCats(null);
        }

        private void loadIconCats(TreeNode parent) {
            String path = "/icons/subcats.xml?node=";
            path += (parent == null) ? "root" : parent.Tag;
            XmlDocument xmlDoc = _httpBasic.getXmlDocument(path);
            XmlNodeList iconCats = xmlDoc.GetElementsByTagName("icon-category");
            TreeNodeCollection collection = (parent == null) ? tvIconCategories.Nodes : parent.Nodes;
            foreach (XmlNode iconCat in iconCats) {
                XmlElement iconCatElement = (XmlElement)iconCat;
                TreeNode newNode = new TreeNode();
                newNode.Nodes.Add(new DummyTreeNode());
                newNode.Text = iconCatElement.GetElementsByTagName("name")[0].InnerText;
                newNode.Tag = iconCatElement.GetElementsByTagName("id")[0].InnerText;
                collection.Add(newNode);
            }
        }

        private void loadIcons(TreeNode node) {
            lstIcons.Items.Clear();
            String path = "/icons.xml?icon_category_id=" + node.Tag;
            XmlDocument xmlDoc = _httpBasic.getXmlDocument(path);
            XmlNodeList icons = xmlDoc.GetElementsByTagName("icon");
            foreach (XmlNode icon in icons) {
                XmlElement iconElement = (XmlElement)icon;
                String filename = iconElement.GetElementsByTagName("filename")[0].InnerText;
                String webPath = iconElement.GetElementsByTagName("web-path")[0].InnerText;
                ListBoxItem item = new ListBoxItem(filename, webPath);
                lstIcons.Items.Add(item);
            }
        }

        private void pnlGoogleEarth_Resize(object sender, EventArgs e) {
            sizeGoogleEarth();
        }

        private void sizeGoogleEarth() {
            WinApi.SetWindowPos(_geApp.GetMainHwnd(), WinApi.HWND_TOP, -4, -30, pnlGoogleEarth.Width + 8, pnlGoogleEarth.Height + 34, WinApi.SWP_SHOWWINDOW);
        }

        private void GooHelloWorld_FormClosing(object sender, FormClosingEventArgs e) {
            WinApi.PostMessage(_geApp.GetMainHwnd(), WinApi.WM_QUIT, 0, 0);
        }

        private void tvIconCategories_BeforeExpand(object sender, TreeViewCancelEventArgs e) {
            TreeNode node = e.Node;
            if (node.Nodes.Count == 1 && node.Nodes[0] is DummyTreeNode) {
                TreeNode dummyNode = node.Nodes[0];
                dummyNode.Remove();
                loadIconCats(node);
            }
        }

        private void tvIconCategories_AfterSelect(object sender, TreeViewEventArgs e) {
            TreeNode node = e.Node;
            loadIcons(node);
        }

        private void lstIcons_SelectedIndexChanged(object sender, EventArgs e) {
            ListBoxItem item = (ListBoxItem)lstIcons.SelectedItem;
            Stream s = _httpBasic.getStream((String)item.getTag());
            System.Drawing.Image image = Bitmap.FromStream(s);
            pctIcon.Image = image;
        }

        private void btnInsertIcon_Click(object sender, EventArgs e) {
            ListBoxItem selected = (ListBoxItem)lstIcons.SelectedItem;
            String webPath = (String)selected.getTag();
            String iconFullPath = _appPath + webPath;
            FileInfo fi = new FileInfo(iconFullPath);
            String iconPath = fi.DirectoryName;
            Directory.CreateDirectory(iconPath);
            pctIcon.Image.Save(iconFullPath, ImageFormat.Gif);
            PointOnTerrainGE center = _geApp.GetPointOnTerrainFromScreenCoords(0, 0);
            String kmlData = null;
            kmlData += "<Folder>";
            kmlData += "<Style id=\"foobar\">";
            kmlData += "<IconStyle>";
            kmlData += "<Icon>";
            kmlData += "<href>" + iconFullPath.Replace('/', '\\') + "</href>";
            kmlData += "</Icon>";
            kmlData += "</IconStyle>";
            kmlData += "</Style>";
            kmlData += "<Placemark>";
            kmlData += "<name>whatever</name>";
            kmlData += "<visibility>1</visibility>";
            kmlData += "<Point>";
            kmlData += "<coordinates>" + center.Longitude + "," + center.Latitude + ",0</coordinates>";
            kmlData += "</Point>";
            kmlData += "<styleUrl>#foobar</styleUrl>";
            kmlData += "</Placemark>";
            kmlData += "</Folder>";
            _geApp.LoadKmlData(ref kmlData);
        }

        private String getAppPath() {
            String exeName = Application.ExecutablePath;
            FileInfo fi = new FileInfo(exeName);
            return fi.DirectoryName;
        }

        private void btnSearchUnits_Click(object sender, EventArgs e) {
            txtUic.Text = txtShortName.Text = txtLongName.Text = "";
            lstUnits.Items.Clear();
            String path = "/units.xml?search=" + txtSearchUnits.Text;
            XmlDocument xmlDoc = _httpBasic.getXmlDocument(path);
            XmlNodeList units = xmlDoc.GetElementsByTagName("unit");
            foreach (XmlNode unit in units) {
                XmlElement unitElement = (XmlElement)unit;
                String uic = unitElement.GetElementsByTagName("uic")[0].InnerText;
                String shortName = unitElement.GetElementsByTagName("short-name")[0].InnerText;
                String id = unitElement.GetElementsByTagName("id")[0].InnerText;
                String description = uic + ": " + shortName;
                ListBoxItem item = new ListBoxItem(description, id);
                lstUnits.Items.Add(item);
            }
        }

        private void lstUnits_SelectedIndexChanged(object sender, EventArgs e) {
            ListBoxItem item = (ListBoxItem)lstUnits.SelectedItem;
            String path = "/units/" + (String)item.getTag() + ".xml";
            XmlDocument xmlDoc = _httpBasic.getXmlDocument(path);
            XmlNode xmlNode = xmlDoc.GetElementsByTagName("unit")[0];
            XmlElement unit = (XmlElement)xmlNode;
            txtUic.Text = unit.GetElementsByTagName("uic")[0].InnerText;
            txtShortName.Text = unit.GetElementsByTagName("short-name")[0].InnerText;
            txtLongName.Text = unit.GetElementsByTagName("long-name")[0].InnerText;
        }

        private void button1_Click(object sender, EventArgs e) {
            MessageBox.Show(_geApp.GetHighlightedFeature().ToString());
        }

    }

    /* C# doesn't like our certifcate on camberhawaii.org */
    public class AcceptAllCertificatePolicy : ICertificatePolicy {
        public AcceptAllCertificatePolicy() { }
        public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate cert, WebRequest req, int certifcateProblem) {
            return true;
        }
    }

    public class HttpBasic {

        private String _username;
        private String _password;
        private String _baseUrl;
        private String _authHeader;
        private CredentialCache _credCache;

        public HttpBasic(String username, String password, String baseUrl) {
            _username = username;
            _password = password;
            _baseUrl = baseUrl;
            _authHeader = "Basic " + Convert.ToBase64String(new ASCIIEncoding().GetBytes(_username + ":" + _password));
            Uri uri = new Uri(_baseUrl);
            _credCache = new CredentialCache();
            _credCache.Add(uri, "Basic", new NetworkCredential(_username, _password));
        }

        public HttpWebResponse get(String path) {
            Uri uri = new Uri(_baseUrl + path);
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(uri);
            req.Credentials = _credCache;
            req.Headers.Add("Authorization", _authHeader);
            return (HttpWebResponse)req.GetResponse();
        }

        public Stream getStream(String path) {
            HttpWebResponse res = get(path);
            return res.GetResponseStream();
        }

        public String getString(String path) {
            Stream stream = getStream(path);
            StreamReader sr = new StreamReader(stream);
            return sr.ReadToEnd();
        }

        public XmlDocument getXmlDocument(String path) {
            String str = getString(path);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(str);
            return xmlDoc;
        }
    }

    public class WinApi {
        public const int HWND_TOP = 0;
        public const int SWP_SHOWWINDOW = 0x40;
        public const int WM_QUIT = 0x0012;

        [DllImport("user32.dll")]
        public static extern int SetParent(int hwndChild, int hwndParent);
        [DllImport("user32.dll")]
        public static extern Boolean EnumChildWindows(int hwndParent, Delegate enumFunc, int lParam);
        [DllImport("user32.dll")]
        public static extern int SetWindowPos(int hwnd, int insertAfterHwnd, int x, int y, int cx, int cy, int flags);
        [DllImport("user32.dll")]
        public static extern bool PostMessage(int hwnd, int msg, int wParam, int lParam);
    }

    public class DummyTreeNode : TreeNode {}

    public class ListBoxItem {
        private String _text;
        private Object _tag;
        public ListBoxItem(String text, Object tag) {
            _text = text;
            _tag = tag;
        }
        /* properties? */
        public Object getTag() {return _tag;}
        public override String ToString() {
            return _text;
        }
    }

}