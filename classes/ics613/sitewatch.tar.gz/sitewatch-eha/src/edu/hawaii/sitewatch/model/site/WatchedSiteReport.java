package edu.hawaii.sitewatch.model.site;

import java.io.Serializable;
import java.util.Date;

import edu.hawaii.sitewatch.util.ServletUtils;

/**
 * Represents a site watch report on a web site.
 *
 * @author David J. Burger
 * @author Xiaohua Chen
 * @author Fengxian Fan
 * @version $Id: WatchedSiteReport.java,v 1.1 2003/12/05 19:06:11 dburger Exp $
 */
public class WatchedSiteReport implements Serializable {

  /** Count of bad links within this site. */
  private int badLinkCount;

  /** Count of new pages within this site. */
  private int newPageCount;

  /** Count of deleted pages within this site. */
  private int deletedPageCount;

  /** Count of modified pages within this site. */
  private int modifiedPageCount;

  /** Array of reports on the individual pages  */
  private WatchedPageReport[] pageReports = null;

  /** The <code>Date</code> the report was made.  */
  private Date reportDate = null;

  /**
   * Constructor that creates a <code>WatchedSiteReport</code> with the given page counts and the
   * array of SiteWatchPageReport.
   *
   * @param newPageCount the number of new pages
   * @param deletedPageCount the number of deleted pages
   * @param modifiedPageCount the number of modified pages
   * @param badLinkCount total number of bad links
   * @param pageReports an array of <code>WatchedPageReports</code>
   */
  public WatchedSiteReport(int newPageCount, int deletedPageCount, int modifiedPageCount,
      int badLinkCount, WatchedPageReport[] pageReports) {
    this.badLinkCount = badLinkCount;
    this.newPageCount = newPageCount;
    this.deletedPageCount = deletedPageCount;
    this.modifiedPageCount = modifiedPageCount;
    this.pageReports = pageReports;
    this.reportDate = new Date();
  }

  /**
   * Returns the array of <code>WatchedPageReport</code>s produced during the crawl.
   *
   * @return array of <code>WatchedPageReport</code>s produced during the
   *     crawl
   */
  public WatchedPageReport[] getWatchedPageReports() {
    return this.pageReports;
  }

  /**
   * Returns the bad link count.
   *
   * @return the bad link count.
   */
  public int getBadLinkCount() {
    return this.badLinkCount;
  }

  /**
   * Returns the total page count.
   *
   * @return the total page count
   */
  public int getTotalPageCount() {
    return this.pageReports.length;
  }

  /**
   * Returns the number of modified pages from this site report.
   *
   * @return count of modified pages
   */
  public int getModifiedPageCount() {
    return this.modifiedPageCount;
  }

  /**
   * Returns the number of new pages from this site report.
   *
   * @return count of new pages
   */
  public int getNewPageCount() {
    return this.newPageCount;
  }

  /**
   * Returns the number of deleted pages from this site report.
   *
   * @return count of deleted pages
   */
  public int getDeletedPageCount() {
    return this.deletedPageCount;
  }

  /**
   * Returns the <code>Date</code> the report was made.
   *
   * @return the <code>Date</code> the report was made
   */
  public Date getReportDate() {
    return this.reportDate;
  }

  /**
   * Returns whether or not the crawl of this site went over the page threshold value for the Site
   * Watch application.  The page threshold value comes from web.xml, defaulting to 500 if it can't
   * be found.  Future enhancements to this application could involve being able to set page
   * thresholds on a site by site basis.
   *
   * @return true if the last crawl went over the page threshold, otherwise false
   */
  public boolean getIsOverPageThreshold() {
    int pageThreshold = ServletUtils.getInstance().getInitParameter("pageThreshold", 500);
    return this.pageReports.length > pageThreshold;
  }

}
