package edu.hawaii.sitewatch.control.command;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.site.WatchedSite;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Implements the DisplayBadLinks command.
 *
 * @author David J. Burger
 * @version $Id: DisplayBadLinksCommand.java,v 1.5 2003/12/05 19:07:56 dburger Exp $
 */
public class DisplayBadLinksCommand implements Command {

  /**
   * Processes the "DisplayBadLinks" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX).
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();
    String userId = (String) session.getAttribute("userId");
    String site = (String) request.getParameter("site");
    SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
    WatchedSite watchedSite = accountManager.getWatchedSite(userId, site);
    request.setAttribute("watchedSite", watchedSite);
    return Page.BAD_LINKS;
  }

}
