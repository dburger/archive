package edu.hawaii.sitewatch.control;

/**
 * Thrown when exceptions occur during JSP processing.
 *
 * @author Philip M. Johnson
 * @author Jitender Miglani (did minor changes)
 * @version $Id: JspException.java,v 1.1 2003/11/04 21:16:43 ffan Exp $
 */
public class JspException extends Exception {
  /**
   * Thrown when exceptions occur during JSP processing.
   *
   * @param detailMessage A detailed string describing the error.
   */
  public JspException(String detailMessage) {
    super(detailMessage);
  }
}
