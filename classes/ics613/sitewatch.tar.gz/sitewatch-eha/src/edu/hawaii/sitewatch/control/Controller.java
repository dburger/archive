package edu.hawaii.sitewatch.control;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import edu.hawaii.sitewatch.util.ServletUtils;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerTimerTask;
import edu.hawaii.sitewatch.control.command.Command;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;

/**
 * The central servlet that serves as the controller in the MVC pattern for JSP page dispatching.
 *
 * @author Philip M. Johnson
 * @author Jitender Miglani (did minor changes)
 * @author David J. Burger (did minor changes)
 * @author Xiaohua Chen (did minor changes)
 * @version $Id: Controller.java,v 1.31 2003/12/05 19:08:30 dburger Exp $
 */
public class Controller extends HttpServlet {

  private String exceptionAttribute = "javax.servlet.jsp.jspException";
  private String commandParameter = "CommandName";

  /**
   * Calls super.init with a <code>ServletConfig</code> argument and initializes the Site Watch
   * application.
   *
   * @param conf The servlet configuration information.
   * @exception ServletException If errors occur during initialization.
   */
  public void init(ServletConfig conf) throws ServletException {
    super.init(conf);
    initSiteWatch(conf);
  }

  /**
   * Used to initialize the Site Watch application.  This includes setting up the mechanism to
   * access functionality and parameters from the <code>ServletConfig</code>, adding the
   * <code>SiteWatchAccountManager</code> as a listener of web crawlers, and starting the web
   * crawler automatic crawl timer.
   *
   * @param conf the servlet configuration information
   */
  private void initSiteWatch(ServletConfig conf) {
    ServletUtils.getInstance().init(conf.getServletContext());
    WebCrawlerManager manager = WebCrawlerManager.getInstance();
    manager.addWebCrawlerListener(SiteWatchAccountManager.getInstance());
    //  get the Date corresponding to midnight 00:00:00am.
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, 1);  // adds one day
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    Date time = calendar.getTime();
    Timer timer = new Timer();
    //execute crawler task every 24 hours starting at midnight
    timer.schedule(new WebCrawlerTimerTask(), time, 24 * 60 * 60 * 1000);
    // for interactive testing use this schedule instead, this is once / minute
    // timer.schedule(new WebCrawlerTimerTask(), 0, 60 * 1000);
  }

  /**
   * Receives all user requests and dispatches to appropriate command class for processing. The
   * command class is determined by the value of the "CommandName" parameter in the request; if
   * none is supplied, then "Display" is assumed.  The command class that is dispatched from this
   * method returns the page that should be displayed in response to the user request.  The command
   * class that is dispatched from this method is responsible for updating the request object with
   * new attributes required by the JSP page.  Many commands require that a user be logged in in
   * order to execute the command.  This is checked by looking for the session variable "userId."
   * If this variable is present, the user is logged in as that user and the command is allowed to
   * execute.  The commands Login, Register, and InitTests are allowed to execute without a logged
   * in user.
   *
   * @param request The servlet request object.
   * @param response The servlet response object.
   * @exception ServletException If problems occur with request or response.
   * @exception IOException If problems occur during request forwarding.
   */
  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    //Every request to this servlet must include the "CommandName" parameter.
    String commandName = request.getParameter(commandParameter);
    // if no command then assume Display
    if (commandName == null) {
      commandName = "Display";
    }
    // if we find the user is not logged in, they will be redirected to welcome.jsp page unless the
    // command is Login, Register, or InitTests
    Page page = Page.WELCOME;
    RequestDispatcher dispatcher = null;
    // Now try to dispatch to the command class responsible for handling the requested Command.
    try {
      HttpSession session = request.getSession(true);
      String userId = (String) session.getAttribute("userId");
      // if the userId is set, the user is logged in and thus we execute their command.  we also
      // execute the users command if they are not logged in, but the command is Login or Register
      // or InitTests
      if (userId != null
          || (userId == null && (commandName.equals("Login") || commandName.equals("Register")
          || commandName.equals("InitTests")))) {
        // process the command.
        String commandClassName = "edu.hawaii.sitewatch.control.command." + commandName
            + "Command";
        Command command = (Command) Class.forName(commandClassName).newInstance();
        page = command.process(request);
      }
    }
    catch (Exception e) {
      page = Page.ERROR;
      request.setAttribute(exceptionAttribute, e);
    }
    request.setAttribute("pageTitle", page.getTitle());
    dispatcher = getServletContext().getRequestDispatcher(page.getFileName());
    // Now forward the updated request object on to the page that will be returned to the user.
    dispatcher.forward(request, response);
  }

  /**
   * Dispatches to doPost for processing.
   *
   * @param request The servlet request.
   * @param response The servlet response.
   * @exception ServletException If problems during request/response processing.
   * @exception IOException If problems during the forward to the JSP page.
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    doPost(request, response);
  }

}
