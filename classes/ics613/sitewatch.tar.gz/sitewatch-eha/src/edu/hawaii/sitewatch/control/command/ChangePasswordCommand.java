package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountException;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;

/**
 * Implements the ChangePassword command.
 *
 * @author Fengxian Fan
 * @version $Id: ChangePasswordCommand.java,v 1.7 2003/12/08 06:06:47 dburger Exp $
 */
public class ChangePasswordCommand implements Command {

  /**
   * Processes the "ChangePassword" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX on valid login,
   *   Page.WELCOME on invalid login)
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();

    // only change to Page.INDEX if successfully changed password
    Page returnPage = Page.CHANGE_PASSWORD;

    String userId = (String) session.getAttribute("userId");

    String password = request.getParameter("password");
    String newPassword1 = request.getParameter("newPassword1");
    String newPassword2 = request.getParameter("newPassword2");

    if (password == null || newPassword1 == null || newPassword2 == null || password.length() == 0
        && newPassword1.length() == 0 || newPassword2.length() == 0) {
      request.setAttribute("message",
          "Invalid password change, please fill in all required fields.");
      // leave returnPage == Page.CHANGE_PASSWORD
    }
    else if (!newPassword1.equals(newPassword2)) {
      request.setAttribute("message", "Your new password entries did not match.");
      // leave returnPage == Page.CHANGE_PASSWORD
    }
    else {
      try {
        SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
        accountManager.changePassword(userId, password, newPassword1);
        request.setAttribute("message", "You have successfully changed your password. Please "
            + "remember it for future use.");
        request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
        WebCrawlerManager crawlerManager = WebCrawlerManager.getInstance();
        request.setAttribute("crawlsInProgress", crawlerManager.getUserIdUrls(userId));
        returnPage = Page.INDEX;
      }
      catch (SiteWatchAccountException e) {
        request.setAttribute("message", e.getMessage());
      }
    }
    return returnPage;
  }

}
