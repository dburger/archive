package edu.hawaii.sitewatch.model.webcrawler;

import com.meterware.httpunit.HttpNotFoundException;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebResponse;

import edu.hawaii.sitewatch.model.site.WatchedPageReport;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * A worker thread class that performs crawls from root URLs and collects data
 * on what it finds.  This class is controlled by the
 * <code>WebCrawlerManager</code>.  This class returns
 * <code>WebCrawlerSiteReport</code>s and asks for root URLs to crawl from in
 * the managers <code>getRootUrl</code> method.  On the first call to
 * getRootUrl a null value will be passed, as the thread hasn't
 * performed a crawl yet.  In getRootUrl the manager will check if root URLs
 * are available, if there are, one is returned immediately.  If no root URLs
 * are available the thread will will be blocked until a root URL becomes
 * available.  When the root URL is returned, the crawl begins and continues
 * until no more pages can be found or until the page threshold is reached.
 * When finished a <code>WebCrawlerSiteReport</code> is constructed that
 * represents the result of the crawl, and is returned to the manager in the
 * next call to getRootUrl.
 *
 * @author David J. Burger
 * @version $Id: WebCrawler.java,v 1.2 2003/12/08 06:06:47 dburger Exp $
 */
public class WebCrawler extends Thread {

  /**
   * Limit on the number of pages that will be crawled for a single site.  Any
   * value less that 1 will be treated as no limit.
   */
  private int pageThreshold;

  /** Provides ability to retrieve and process URL contents. */
  private WebConversation conversation = null;

  /** Used to stop the thread. */
  private boolean stopRequested;

  /** Used as a value entry in <code>urlMap</code> to indicate a bad link. */
  private static final WatchedPageReport BAD_LINK = new WatchedPageReport("bad link", 0);

  /**
   * Constructs a new <code>WebCrawler</code> with the give page threshold
   * value.
   *
   * @param pageThreshold the limit on the number of pages that will be crawled
   *     for a single site, pass in any value less than 1 for no limit
   */
  public WebCrawler(int pageThreshold) {
    this.pageThreshold = pageThreshold;
    this.conversation = new WebConversation();
    this.stopRequested = false;
  }

  /**
   * Places a request for this thread to stop, abandoning any crawl in
   * progress.  The synchronization is used for communication between threads
   * to ensure that they see the up to date value of stopRequested.
   */
  public synchronized void requestStop() {
    this.stopRequested = true;
  }

  /**
   * Returns whether or not a stop has been requested for this thread.  The
   * synchronization is used for communication between threads to ensure that
   * they see the up to date value of stopRequested.
   *
   * @return true if a stop has been requested, otherwise false
   */
  public synchronized boolean isStopRequested() {
    return this.stopRequested;
  }

  /**
   * The main thread loop that asks the <code>WebCrawlerManager</code> for
   * a root URL, and then begins the crawl when one is returned.  If a root URL
   * isn't immediately available, the manager will block this thread in the
   * call to getRootUrl until a root URL is available.  This thread can be
   * terminated by a call to the <code>terminate</code> method.
   */
  public void run() {

    WebCrawlerSiteReport siteReport = null;
    WebCrawlerManager manager = WebCrawlerManager.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");

    // main loop, loop until manager calls terminate
    while (!isStopRequested()) {

      // this LinkedList will be used to hold the urls to produce a BFS traversal of the site, we
      // use a LinkedList because the removals will be from the front of the list, which is
      // expensive for ArrayList
      List urlQueue = new LinkedList();

      // this TreeMap will be used to reject duplicate URLs and hold the WatchedPageReport objects
      // for the pages to be included in the report...pages not included in the report will still be
      // kept in the mapping to reject duplicates, but the value field will be left null bad links
      // will be identified in this mapping by the value BAD_LINK a TreeMap is used because it will
      // provide a sorted view
      Map urlMap = new TreeMap();

      // return a report and ask for a root URL, blocked until one is available
      String rootUrl = manager.getRootUrl(siteReport);

      try {
        urlQueue.add(new ContextUrl(rootUrl, null));
      }
      catch (MalformedURLException e) {
        // rootUrl invalid, make empty report and ask for next rootUrl
        siteReport = new WebCrawlerSiteReport(rootUrl, new WatchedPageReport[0], 0);
        continue;
      }

      urlMap.put(rootUrl, null);
      int pageCount = 0;

      // the BFS loop
      while (!isStopRequested() && urlQueue.size() > 0 && pageCount <= this.pageThreshold) {

        ContextUrl contextUrl = (ContextUrl) urlQueue.remove(0);

        try {
          WebResponse response = conversation.getResponse(contextUrl.getNormalizedUrl());
          String lastModifiedString = response.getHeaderField("Last-Modified");
          Date lastModifiedDate = new Date(0);
          try {
            lastModifiedDate = dateFormat.parse(lastModifiedString);
          }
          catch (Exception e) {
            // NullPointerException on lastModifedString or ParseException
            // on parsing the date, leave the date as the Unix epoch
          }

          urlMap.put(contextUrl.getNormalizedUrl(), new WatchedPageReport(
              contextUrl.getNormalizedUrl(), lastModifiedDate.getTime()));
          pageCount++;

          processLinks(rootUrl, response.getLinks(),
              contextUrl.getNormalizedUrl(), urlQueue, urlMap);

        }
        catch (HttpNotFoundException e) {
          urlMap.put(contextUrl.getNormalizedUrl(), WebCrawler.BAD_LINK);
          // for all URLs except rootUrl getContextUrl() != null
          if (contextUrl.getContextUrl() != null) {
            WatchedPageReport report = (WatchedPageReport) urlMap.get(contextUrl.getContextUrl());
            if (report != null) {
              // report the bad link as seen on page, not in normalized form
              report.addBadLink(contextUrl.getOriginalUrl());
            }

          }
        }
        catch (Exception e) {
          // IOException, SAXException, NotHTMLException, whatever,
          // try next URL in urlQueue
        }

      }

      // set up report to be sent back to the manager from reports in urlMap
      siteReport = createSiteReport(rootUrl, pageCount, urlMap);
    }
  }

  /**
   * Performs link processing for this <code>WebCrawler</code> for the links
   * found on a single page.
   *
   * @param rootUrl the root URL for this crawl
   * @param links the links to be processed
   * @param context the URL these links were found on
   * @param urlQueue the queue used to produce the BFS traversal for this crawl
   * @param urlMap the map used to reject duplicates and hold reports for this
   *     crawl
   */
  private void processLinks(String rootUrl, WebLink[] links, String context, List urlQueue,
      Map urlMap) {
    WatchedPageReport report = null;
    for (int i = 0; i < links.length; i++) {
      try {
        ContextUrl url = new ContextUrl(links[i].getURLString(), context);
        if (url.getNormalizedUrl().startsWith(rootUrl)) {
          if (urlMap.containsKey(url.getNormalizedUrl())) {
            if (urlMap.get(url.getNormalizedUrl()) == WebCrawler.BAD_LINK) {
              // fake the exception to get the equivalent bad link report
              throw new MalformedURLException();
            }
          }
          else {
            urlQueue.add(url);
            urlMap.put(url.getNormalizedUrl(), null);
          }
        }
      }
      catch (MalformedURLException e) {
        report = (WatchedPageReport) urlMap.get(context);
        if (report != null) {
          // report the link as seen on the page
          report.addBadLink(links[i].getURLString());
        }
      }
    }
  }

  /**
   * Creates a <code>WebCrawlerSiteReport</code> for a crawl.  The report is
   * constructed from the <code>WatchedPageReport</code>s that can be found
   * in <code>urlMap</code>.
   *
   * @param rootUrl the root URL for the crawl that produced this site report
   * @param pageCount number of valid page reports located in urlMap
   * @param urlMap the mapping that contains the page reports found during the
   *     crawl
   * @return a <code>WebCrawlerSiteReport</code> that represents the results of
   *     the given crawl
   */
  private WebCrawlerSiteReport createSiteReport(String rootUrl, int pageCount, Map urlMap) {
    int numBadLinks = 0;
    WatchedPageReport[] WatchedPageReports = new WatchedPageReport[pageCount];
    Iterator i = urlMap.values().iterator();
    int j = 0;
    while (i.hasNext() && j < pageCount) {
      WatchedPageReport report = (WatchedPageReport) i.next();
      if (report != null && report != WebCrawler.BAD_LINK) {
        WatchedPageReports[j++] = report;
        numBadLinks += report.getBadLinks().length;
      }
    }
    return new WebCrawlerSiteReport(rootUrl, WatchedPageReports, numBadLinks);
  }

  /**
   * Represents a URL along with its context, that is the URL of the page that
   * the URL was found on.
   *
   * @author David J. Burger
   * @version $Id: WebCrawler.java,v 1.2 2003/12/08 06:06:47 dburger Exp $
   */
  protected class ContextUrl {

    /** The URL as it appeared on the context page. */
    private String originalUrl = null;

    /** URL of page that the this URL was on. */
    private String contextUrl = null;

    /** The normalized version of the URL. */
    private String normalizedUrl = null;

    /**
     * Constructs a <code>ContextUrl</code> with the given original url and
     * context.
     *
     * @param originalUrl the actual URL as seen on the context page
     * @param contextUrl the URL of the page originalUrl is found on
     * @throws MalformedURLException if a normalized URL cannot be made from
     *     originalUrl and contextUrl
     */
    public ContextUrl(String originalUrl, String contextUrl) throws MalformedURLException {
      this.originalUrl = originalUrl;
      this.contextUrl = contextUrl;
      if (contextUrl != null) {
        this.normalizedUrl = new URL(new URL(contextUrl), originalUrl).toExternalForm();
      }
      else {
        this.normalizedUrl = originalUrl;
      }
    }

    /**
     * Returns the original URL as seen on the context page.
     *
     * @return the original URL as seen on the context page
     */
    public String getOriginalUrl() {
      return this.originalUrl;
    }

    /**
     * Returns the context of this URL.
     *
     * @return the context of this URL
     */
    public String getContextUrl() {
      return this.contextUrl;
    }

    /** Returns the normalized URL.
     *
     * @return the normalized URL
     */
    public String getNormalizedUrl() {
      return this.normalizedUrl;
    }

  }

}
