package edu.hawaii.sitewatch.control.command;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Implements the Display command.
 *
 * @author David J. Burger
 * @version $Id: DisplayCommand.java,v 1.8 2003/12/05 19:07:56 dburger Exp $
 */
public class DisplayCommand implements Command {

  /**
   * Processes the "Display" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX).
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();
    String userId = (String) session.getAttribute("userId");
    SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
    request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
    WebCrawlerManager crawlerManager = WebCrawlerManager.getInstance();
    request.setAttribute("crawlsInProgress", crawlerManager.getUserIdUrls(userId));
    return Page.INDEX;
  }

}
