package edu.hawaii.sitewatch.model.account;

import java.io.File;
import java.io.IOException;

import edu.hawaii.sitewatch.util.ServletUtils;
import edu.hawaii.sitewatch.model.site.WatchedSite;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerListener;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerSiteReport;

/**
 * Provides access to the <code>SiteWatchAccount</code>s storing the user
 * data.  This class is a singleton to insure that only one copy of the
 * <code>HashMap</code> exists that maps the user ids to accounts.
 * This class implements <code>WebCrawlerListener</code> so that it can
 * receive the <code>WebCrawlerReport</code>s from the
 * <code>WebCrawlerManager</code> and enter the data into the data store.
 *
 * @author David J. Burger
 * @author Fengxian Fan (add method changePassword, add triggerEmail part)
 * @version $Id: SiteWatchAccountManager.java,v 1.3 2003/12/08 06:06:47 dburger Exp $
 */
public class SiteWatchAccountManager implements WebCrawlerListener {

  /** The singleton <code>SiteWatchAccounts</code> instance. */
  private static SiteWatchAccountManager theInstance = null;

  /**
   * Used to retrieve the singleton <code>SiteWatchAccountManager</code>.
   *
   * @return the singleton <code>SiteWatchAccountManager</code>
   */
  public static synchronized SiteWatchAccountManager getInstance() {
    if (SiteWatchAccountManager.theInstance == null) {
      SiteWatchAccountManager.theInstance = new SiteWatchAccountManager();
    }
    return SiteWatchAccountManager.theInstance;
  }


  /**
   * Creates an account with the given user ID.
   *
   * @param userId user ID for new account
   * @param emailAddress the email address for this account
   * @param password the password for this account
   * @throws SiteWatchAccountException if the account can't be create if the
   *   new account is invalid such as the user ID already being in use
   */
  public synchronized void createSiteWatchAccount(String userId, String emailAddress,
      String password) throws SiteWatchAccountException {
    if (SiteWatchAccount.load(userId) != null) {
      throw new SiteWatchAccountException("User ID " + userId + " is already in use.");      
    }
    try {
      new SiteWatchAccount(userId, emailAddress, password).save();      
    }
    catch (IOException e) {
      ServletUtils.getInstance().log("createSiteWatchAccount: Unable to save the account "
          + userId);
      throw new SiteWatchAccountException("Unable to save your account.");
    }
  }

  /**
   * Used to change the password for the given user ID.
   *
   * @param userId ID of user to change password of
   * @param currentPassword the current password of the user
   * @param newPassword the new password
   * @throws SiteWatchAccountException if the account does not exist
   */
  public synchronized void changePassword(String userId, String currentPassword, String newPassword)
      throws SiteWatchAccountException {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      ServletUtils.getInstance().log("Unable to locate account for logged in user " + userId + ".");
    }
    // NullPointerException will propagate back to Controller.java and will
    // result in the display of Page.ERROR
    if (account.getPassword().equals(currentPassword)) {
      account.setPassword(newPassword);
      try {
        account.save();
      }
      catch (IOException e) {
        ServletUtils.getInstance().log("changePassword: Unable to save the account " + userId);
        throw new RuntimeException("Unable to save your account.");
      }
    }
    else {
      throw new SiteWatchAccountException("Your current password is incorrect, please check it and "
          + "try again.");
    }
  }

  /**
   * Checks if the given userId / password is a valid user login.
   *
   * @param userId the user Id
   * @param password the password for the given user Id
   * @return true if the user is a valid user Id / password combination,
   *   false otherwise
   */
  public synchronized boolean isValidUser(String userId, String password) {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      return false;
    }
    return account.getPassword().equals(password);
  }

  /**
   * Adds the site indicated by <code>rootUrl</code> to the list of sites
   * being watched by the account corresponding to <code>userId</code>.
   *
   * @param userId the user id of the account to add the site to
   * @param rootUrl the root url of the site to add to the watched list
   * @param triggersEmail the boolean value marking if the crawlering result
   *        needs to br sent to the user
   * @throws SiteWatchAccountException if this add would result in more sites in the watch list
   *     than that allowed by the siteThreshold value
   *
   */
  public synchronized void addSite(String userId, String rootUrl, boolean triggersEmail)
      throws SiteWatchAccountException {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      ServletUtils.getInstance().log("Unable to locate account for logged in user " + userId + ".");
    }
    // NullPointerException will propagate back to Controller.java and will
    // result in the display of Page.ERROR
    account.addSite(rootUrl, triggersEmail);
    try {
      account.save();
    }
    catch (IOException e) {
      ServletUtils.getInstance().log("addSite: Unable to save the account " + userId);
      throw new RuntimeException("Unable to save your account.");
    }
  }

  /**
   * Removes the sites in the passed in array from the list of sites being
   * watched by the account corresponding to <code>userId</code>.
   *
   * @param userId user ID of account to remove the sites from
   * @param sites array of sites to remove from being watched
   */
  public void removeSites(String userId, String[] sites) {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      ServletUtils.getInstance().log("Unable to locate account for logged in user " + userId + ".");
    }
    // NullPointerException will propagate back to Controller.java and will
    // result in the display of Page.ERROR
    account.removeSites(sites);
    try {
      account.save();
    }
    catch (IOException e) {
      ServletUtils.getInstance().log("removeSites: Unable to save the account " + userId);
      throw new RuntimeException("Unable to save your account.");
    }
  }

  /**
   * Modifies the email alert settings for the given user sites so that all
   * those listed in sites are true and all others are false.
   *
   * @param userId user ID of account to modify email settings for
   * @param sites array of sites whose email alert setting should be true
   */
  public synchronized void modifyEmailSettings(String userId, String[] sites) {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      ServletUtils.getInstance().log("Unable to locate account for logged in user " + userId + ".");
    }
    // NullPointerException will propagate back to Controller.java and will
    // result in the display of Page.ERROR
    account.modifyEmailSettings(sites);
    try {
      account.save();
    }
    catch (IOException e) {
      ServletUtils.getInstance().log("modifyEmailSettings: Unable to save the account " + userId);
      throw new RuntimeException("Unable to save your account.");
    }

  }

  /**
   * Returns an array containing the <code>WatchedSite</code>s object for
   * the specified user, or null, if the user account can't be found.
   *
   * @param userId user to return the <code>Map</code> for
   * @return array of sites being watch by the user
   */
  public synchronized WatchedSite[] getWatchedSites(String userId) {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      ServletUtils.getInstance().log("Unable to locate account for logged in user " + userId + ".");
    }
    // NullPointerException will propagate back to Controller.java and will
    // result in the display of Page.ERROR
    return account.getWatchedSites();
  }

  /**
   * Returns the <code>WatchedSite</code> for the corresponding user and
   * url.  Null is returned if the user does not exist or the site does
   * not exist for the given user.
   *
   * @param userId user to return the <code>WatchedSite</code> for
   * @param url the URL of the site to return the <code>WatchedSite</code> of
   * @return the <code>WatchedSite</code> corresponding to the given URL or
   *     null if there is none
   */
  public synchronized WatchedSite getWatchedSite(String userId, String url) {
    SiteWatchAccount account = SiteWatchAccount.load(userId);
    if (account == null) {
      ServletUtils.getInstance().log("Unable to locate account for logged in user " + userId + ".");
    }
    // NullPointerException will propagate back to Controller.java and will
    // result in the display of Page.ERROR
    return account.getWatchedSite(url);
  }

  /**
   * Used to start the crawling of root URLs for every root URL for every user.
   */
  public synchronized void startAutomaticCrawls() {
    ServletUtils servletUtils = ServletUtils.getInstance();
    String dataPath = servletUtils.getInitParameter("dataPath", "/WEB-INF/db/");
    if (dataPath == null) {
      dataPath = "/WEB-INF/db/";
      servletUtils.log("context-param dataPath not specified in web.xml, defaulting to " + dataPath
          + ".");
    }
    dataPath = servletUtils.getRealPath(dataPath);
    File dataDir = new File(dataPath);
    String[] files = dataDir.list();
    for (int i = 0; i < files.length; i++) {
      if (!".".equals(files[i]) && !"..".equals(files[i])) {
        SiteWatchAccount account = SiteWatchAccount.load(files[i]);
        if (account != null) {
          account.startAutomaticCrawl();
        }
        else {
          servletUtils.log("startAutomaticCrawl: Unable to load " + files[i] + " from the data "
              + "directory " + dataPath + ".");
        }
      }
    }
  }

  /**
   * Updates the <code>SiteWatchAccount</code>s that the crawl was done for
   * to include the result of the crawl.
   *
   * @param report the <code>WebCrawlerReport</code> of the finished crawl
   * @param userIds the user IDs to be updated witht the crawl report
   */
  public synchronized void webCrawlerFinished(WebCrawlerSiteReport report,
      String[] userIds) {
    for (int i = 0; i < userIds.length; i++) {
      SiteWatchAccount account = SiteWatchAccount.load(userIds[i]);
      // if account == null, the account was deleted after the crawl was
      // initiated but before the report was sent
      if (account != null) {
        account.updateSiteReport(report);
        try {
          account.save();          
        }
        catch (IOException e) {
          ServletUtils.getInstance().log("webCrawlerFinished: Unable to save the account "
              + userIds[i]);          
        }
      }
    }
  }

}
