package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountException;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;

/**
 * Used to initialize test accounts and test crawls used in unit testing of the Site Watch
 * application.
 *
 * @author David J. Burger
 * @version $Id: InitTestsCommand.java,v 1.10 2003/12/08 06:06:47 dburger Exp $
 */
public class InitTestsCommand implements Command {

  /**
   * Processes the "InitTestsCommand" used to initialize test accounts and test crawls used during
   * unit testing of the Site Watch application.
   *
   * @param request The request object.
   * @return The page to be displayed
   */
  public Page process(HttpServletRequest request) {
    SiteWatchAccountManager manager = SiteWatchAccountManager.getInstance();
    try {
      // the test account is used for testing basic operations
      manager.createSiteWatchAccount("test", "test@test.com", "test");
      // the testcrawler account is used to test end to end crawling operations for the sites
      // deleted/, modified/, and new/.
      manager.createSiteWatchAccount("testcrawler", "test@test.com", "testcrawler");
    }
    catch (SiteWatchAccountException e) {
      // if persistence has been implemented we will get duplicate account error
      request.setAttribute("message", e.getMessage());
    }

    String[] urls = new String[] {
        "http://localhost:8080/test-sitewatch/modified/",
        "http://localhost:8080/test-sitewatch/new/",
        "http://localhost:8080/test-sitewatch/deleted/"
    };

    // remove so that we start with a clean slate
    manager.removeSites("testcrawler", urls);
    for (int i = 0; i < urls.length; i++) {
      try {
        manager.addSite("testcrawler", urls[i], false);
      }
      catch (SiteWatchAccountException e) {
        // only from going over siteThreshold, shouldn't happen with testcrawler account
      }
    }
    // a crawl is initiated to set a baseline for the crawl data for the testcrawler user, ant will
    // be used to make changes to the sites and unit tests will initiate crawls to recognize the
    // changes
    WebCrawlerManager.getInstance().addRootUrls("testcrawler", urls);
    return Page.WELCOME;
  }

}
