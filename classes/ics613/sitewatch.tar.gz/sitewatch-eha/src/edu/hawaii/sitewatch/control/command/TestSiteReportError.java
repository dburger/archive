package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests operation of checking unreachable page for testing sites.
 *
 * @author Xiaohua Chen
 * @version $Id: TestSiteReportError.java,v 1.8 2003/12/08 20:24:23 xiaohua Exp $
 */
public class TestSiteReportError extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the unreachable pages.
   *
   * @throws Exception If problems occur
   */
  public void testUnreachablePage() throws Exception {
    WebConversation conversation = new WebConversation();

    // not reachable url
    String url = testHost + "bogusurl.html/";

    String columnHeader = "LastCheck";
    String expected = "not reachable";

    String userId = "test";
    String password = "test";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add the not reachable URL onto the sitewatch
    response = assertAddSite(conversation, response, url, false);

    // now crawl the URL
    response = assertStartCrawl(conversation, response, url);

    // make sure the crawl has time to finish, 5 seconds should be enough
    synchronized (this) {
      wait(5000);
    }

    // now refresh to get updated result from crawl, expecting index.jsp.
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());

    // and the Last Check cell for the URL should say "not reachable"
    assertSitesTableValue(response, url, columnHeader, expected);

    //  clean up after ourselves by removing our added URL
    assertRemoveSite(conversation, response, url);
  }

}
