package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;

/**
 * Implements the Remove site command.
 *
 * @author Fengxian Fan
 * @author David J. Burger
 * @version $Id: RemoveCommand.java,v 1.7 2003/12/05 19:07:56 dburger Exp $
 */
public class RemoveCommand implements Command {

  /**
   * Processes the "Remove" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX).
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();
    String userId = (String) session.getAttribute("userId");
    String[] sites = request.getParameterValues("site");
    SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
    if (sites != null) {
      accountManager.removeSites(userId, sites);
    }
    request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
    WebCrawlerManager crawlerManager = WebCrawlerManager.getInstance();
    request.setAttribute("crawlsInProgress", crawlerManager.getUserIdUrls(userId));
    return Page.INDEX;
  }

}
