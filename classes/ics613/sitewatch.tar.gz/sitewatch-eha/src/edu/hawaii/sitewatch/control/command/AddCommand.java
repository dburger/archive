package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountException;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;

/**
 * Implements the Add site command.
 *
 * @author Xiaohua Chen
 * @author David J. Burger
 * @version $Id: AddCommand.java,v 1.12 2003/12/08 06:06:47 dburger Exp $
 */
public class AddCommand implements Command {

  /**
   * Processes the "Add site" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX).
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();
    String userId = (String) session.getAttribute("userId");
    String newSite = request.getParameter("newSite");
    String triggersEmail = request.getParameter("emailAlerts");
    SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
    if (newSite != null && newSite.length() > 7 && newSite.startsWith("http://")) {
      try {
        accountManager.addSite(userId, newSite, triggersEmail != null);
      }
      catch (SiteWatchAccountException e) {
        // over the siteThreshold, add disallowed
        request.setAttribute("message", e.getMessage());
      }
    }
    else {
      request.setAttribute("url", newSite);
      request.setAttribute("message", "The URL appears to be invalid, please "
        + "check and try again.");
    }
    request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
    WebCrawlerManager crawlerManager = WebCrawlerManager.getInstance();
    request.setAttribute("crawlsInProgress", crawlerManager.getUserIdUrls(userId));
    return Page.INDEX;
  }

}
