package edu.hawaii.sitewatch.model.webcrawler;

import edu.hawaii.sitewatch.model.site.WatchedPageReport;

/**
 * The report that a <code>WebCrawler</code> produces while crawling a site.
 *
 * @author David J. Burger
 * @version $Id: WebCrawlerSiteReport.java,v 1.1 2003/12/05 19:06:38 dburger Exp $
 */
public class WebCrawlerSiteReport {

  /** The root URL for the crawl. */
  private String rootUrl = null;

  /** Array of reports on the individual pages found during the crawl. */
  private WatchedPageReport[] watchedPageReports = null;

  /** The number of bad links found during the crawl. */
  private int numBadLinks;

  /**
   * Constructor that sets the crawl report data.
   *
   * @param rootUrl the root URL for the crawl
   * @param watchedPageReports the array of <code>WatchedPageReport</code>s from the crawl
   * @param numBadLinks the number of bad links found during the crawl
   */
  public WebCrawlerSiteReport(String rootUrl, WatchedPageReport[] watchedPageReports,
      int numBadLinks) {
    this.rootUrl = rootUrl;
    this.watchedPageReports = watchedPageReports;
    this.numBadLinks = numBadLinks;
  }

  /**
   * Returns the array of <code>WatchedPageReport</code>s produced during the crawl.
   *
   * @return array of <code>WatchedPageReport</code>s produced during the crawl
   */
  public WatchedPageReport[] getWatchedPageReports() {
    return this.watchedPageReports;
  }

  /**
   * Returns the count of pages found during the crawl.
   *
   * @return count of pages found during crawl
   */
  public int getPageCount() {
    return this.watchedPageReports.length;
  }

  /**
   * Returns the count of bad links found during the crawl.
   *
   * @return count of bad links found during crawl
   */
  public int getBadLinkCount() {
    return this.numBadLinks;
  }

  /**
   * Returns the root URL for the crawl that this report represents.
   *
   * @return root URL for the crawl that this report represents
   */
  public String getRootUrl() {
    return this.rootUrl;
  }

}
