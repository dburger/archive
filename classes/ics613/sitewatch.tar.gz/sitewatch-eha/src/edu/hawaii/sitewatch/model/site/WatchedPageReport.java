package edu.hawaii.sitewatch.model.site;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

/**
 * Represents a report on a single page from crawling the page.
 *
 * @author David J. Burger
 * @version $Id: WatchedPageReport.java,v 1.1 2003/12/05 19:06:11 dburger Exp $
 */
public class WatchedPageReport implements Serializable {

  /** Last modified time of the page. */
  private long lastModified;

  /** The URL of the page. */
  private String url = null;
  
  /** The links on this page that don't work. */
  private Set badLinks = null;
  
  /**
   * Create a <code>WatchedPageReport</code> with the given url and last
   * modified time.
   *
   * @param url the url string of the page
   * @param lastModified the last modified time of the page
   */
  public WatchedPageReport(String url, long lastModified) {
    this.url = url;
    this.lastModified = lastModified;
    // TreeSet will give us a sorted view of the bad links
    this.badLinks = new TreeSet();
  }

  /**
   * Returns the last modified time of the page.
   *
   * @return the last modified time of the page
   */
  public long getLastModified() {
    return this.lastModified;
  }

  /**
   * Returns the URL of the page.
   *
   * @return the URL of the page
   */
  public String getUrl() {
    return this.url;
  }
  
  /**
    * Returns the bad links that were found on the page represented by this
    * report in a <code>String</code> array.
    *
    * @return the bad links found on the page represented by this report
    */
   public String[] getBadLinks() {
     return (String[]) this.badLinks.toArray(new String[0]);
   }
  
  /**
   * Adds the given link to the set of bad links for this page.
   * 
   * @param link the bad link to add
   */
  public void addBadLink(String link) {
    this.badLinks.add(link);
  }

}
