package edu.hawaii.sitewatch.control.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import edu.hawaii.sitewatch.model.webcrawler.WebCrawlerManager;
import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;

/**
 * Implements the Check command.
 *
 * @author David J. Burger
 * @version $Id: CheckCommand.java,v 1.5 2003/12/05 19:07:56 dburger Exp $
 */
public class CheckCommand implements Command {

  /**
   * Processes the "Check" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX).
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();
    String userId = (String) session.getAttribute("userId");
    String[] sites = request.getParameterValues("site");
    WebCrawlerManager crawlerManager = WebCrawlerManager.getInstance();
    if (sites != null) {
      crawlerManager.addRootUrls(userId, sites);
    }
    SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
    request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
    request.setAttribute("crawlsInProgress", crawlerManager.getUserIdUrls(userId));
    return Page.INDEX;
  }

}
