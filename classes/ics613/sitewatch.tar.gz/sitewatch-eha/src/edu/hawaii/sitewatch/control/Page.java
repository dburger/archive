package edu.hawaii.sitewatch.control;

/**
 * Provides a type-safe enumeration for JSP Page names.
 *
 * @author Philip M. Johnson
 * @author Jitender Miglani (did minor changes)
 * @author David J. Burger (did additions / changes to pages)
 * @version $Id: Page.java,v 1.12 2003/12/04 20:07:21 dburger Exp $
 */
public class Page {

  /** The filename of the JSP page */
  private String fileName;

  /** The title of the JSP page */
  private String title;

  /** Error page for exceptions. */
  public static Page ERROR = new Page("/Error.jsp", "Site Watch Error");

  /** Main display page for application. */
  public static Page INDEX = new Page("/index.jsp", "Site Watch Display");

  /** Home page for application. */
  public static Page WELCOME = new Page("/welcome.jsp", "Site Watch");

  /** Registration page for application. */
  public static Page REGISTER = new Page("/register.jsp", "Site Watch");

  /** Account modification page for application. */
  public static Page CHANGE_PASSWORD = new Page("/changepassword.jsp",
      "Site Watch");

  /** Bad links display page for application. */
  public static Page BAD_LINKS = new Page("/badlinks.jsp",
      "Site Watch Bad Links");

  /** Email settings display page for application. */
  public static Page EMAIL_SETTINGS = new Page("/emailsettings.jsp",
      "Site Watch Email Settings");

  /** Not reachable display page for the application. */
  public static Page NOT_REACHABLE = new Page("/notreachable.jsp",
      "Site Watch Not Reachable");

  /** Over page threshold page for the application. */
  public static Page OVER_PAGE_THRESHOLD = new Page("/overpagethreshold.jsp",
      "Site Watch Over Page Threshold");

  /**
   * Constructs the JSP Page instance.
   * 
   * @param fileName The filename of the JSP page
   * @param title The title of the JSP page
   */
  private Page(String fileName, String title) {
    this.fileName = fileName;
    this.title = title;
  }

  /**
   * Gets the title attribute of the Page object.
   *
   * @return The title value
   */
  public String getTitle() {
    return this.title;
  }

  /**
   * Gets the fileName attribute of the Page object.
   *
   * @return The fileName value
   */
  public String getFileName() {
    return this.fileName;
  }

}
