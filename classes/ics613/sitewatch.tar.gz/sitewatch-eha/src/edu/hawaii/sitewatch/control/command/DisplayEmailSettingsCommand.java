package edu.hawaii.sitewatch.control.command;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Implements the DisplayEmailSettings command.
 *
 * @author Philip Johnson
 * @author David J. Burger (did minor changes)
 * @version $Id: DisplayEmailSettingsCommand.java,v 1.3 2003/12/05 19:07:56 dburger Exp $
 */
public class DisplayEmailSettingsCommand implements Command {

  /**
   * Processes the "DisplayEmailSettings" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX).
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();
    String userId = (String) session.getAttribute("userId");
    SiteWatchAccountManager accountManager = SiteWatchAccountManager.getInstance();
    request.setAttribute("watchedSites", accountManager.getWatchedSites(userId));
    return Page.EMAIL_SETTINGS;
  }

}
