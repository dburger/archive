package edu.hawaii.sitewatch.model.webcrawler;

import junit.framework.TestCase;

/**
 * Tests the operation of the web crawler package.
 *
 * @author David J. Burger
 * @version $Id: TestWebCrawler.java,v 1.2 2003/12/08 00:56:18 dburger Exp $
 */
public class TestWebCrawler extends TestCase {


  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Used to retrieve the <code>WebCrawlerSiteReport</code> for the given URL,
   * blocking until the site report is available or until a timeout.
   *
   * @param userId the user ID to associate with the crawl
   * @param url the url to crawl
   * @param timeout the number of seconds to wait for the report
   * @return the site report of the crawl
   * @throws InterruptedException if the wait is interrupted
   */
  private WebCrawlerSiteReport getSiteReport(String userId, String url,
      int timeout) throws InterruptedException {
    MockWebCrawlerListener listener = new MockWebCrawlerListener();
    WebCrawlerManager manager = WebCrawlerManager.getInstance();
    manager.addWebCrawlerListener(listener);
    manager.addRootUrl(userId, url);

    // wait for the crawl to be complete, listener will notify,
    // or timeout seconds
    synchronized (listener) {
      listener.wait(timeout * 1000);
    }

    return listener.getWebCrawlerSiteReport();
  }

  /**
   * Tests the operation of the crawler when give a bogus or invalid URL.
   *
   * @throws InterruptedException if the wait is interrupted
   */
  public void testBogusUrl() throws InterruptedException {
    WebCrawlerSiteReport siteReport =
        getSiteReport("bob", this.testHost + "test-sitewatch/bogusurl.html", 20);

    // make sure that we didn't time out
    assertNotNull("Expecting not to have timed out.", siteReport);

    // and the URL count should be 0
    assertEquals("Expected 0 pages found for bogus URL.", 0,
        siteReport.getPageCount());
  }

  /**
   * Tests the operation of the crawler when given a URL with one page with
   * no links.
   *
   * @throws InterruptedException if the wait is interrupted
   */
  public void testNoLinks() throws InterruptedException {
    WebCrawlerSiteReport siteReport =
        getSiteReport("bob", this.testHost + "test-sitewatch/one/index.html", 20);

    // make sure that we didn't time out
    assertNotNull("Expecting not to have timed out.", siteReport);

    // and the URL count should be 0
    assertEquals("Expected 1 page found for no links.", 1,
        siteReport.getPageCount());
  }

  /**
   * Tests the operation of the crawler when given a URL to a page that has
   * links, but no links within the same site.
   *
   * @throws InterruptedException if the wait is interrupted
   */
  public void testExternalLinks() throws InterruptedException {
    WebCrawlerSiteReport siteReport =
        getSiteReport("bob", this.testHost + "test-sitewatch/two/", 20);

    // make sure that we didn't time out
    assertNotNull("Expecting not to have timed out.", siteReport);

    // and the URL count should be 0
    assertEquals("Expected 1 page found for no internal links.", 1,
        siteReport.getPageCount());
  }

  /**
   * Tests the operation of the crawler when given a URL to a page that has
   * a single link that goes to a page within the same site.
   *
   * @throws InterruptedException if the wait is interrupted
   */
  public void testOneInternalLink() throws InterruptedException {
    WebCrawlerSiteReport siteReport =
        getSiteReport("bob", this.testHost + "test-sitewatch/three/", 20);

    // make sure that we didn't time out
    assertNotNull("Expecting not to have timed out.", siteReport);

    // and the URL count should be 0
    assertEquals("Expected 2 pages found for single internal link.", 2,
        siteReport.getPageCount());
  }

  /**
   * Tests the operation of the crawler when given a URL to a page that has
   * several internal links.
   *
   * @throws InterruptedException if the wait is interrupted
   */
  public void testMultipleInternalLinks() throws InterruptedException {
    WebCrawlerSiteReport siteReport =
        getSiteReport("bob", this.testHost + "test-sitewatch/four/", 20);

    // make sure that we didn't time out
    assertNotNull("Expecting not to have timed out.", siteReport);

    // and the URL count should be 0
    assertEquals("Expected 6 pages for multiple internal links.", 6,
        siteReport.getPageCount());
  }

  /**
   * Tests the operation of the crawler when given a URL to a page that has
   * several internal links, including cycles.
   *
   * @throws InterruptedException if the wait is interrupted
   */
  public void testCycles() throws InterruptedException {
    WebCrawlerSiteReport siteReport =
        getSiteReport("bob", this.testHost + "test-sitewatch/five/", 20);

    // make sure that we didn't time out
    assertNotNull("Expecting not to have timed out.", siteReport);

    // and the URL count should be 0
    assertEquals("Expected 6 pages for multiple internal links with cycles",
        6, siteReport.getPageCount());
  }

}

/**
 * Used to block and wait for site reports from web crawls in order to
 * facilitate the testing of the asynchronous crawls in the web crawler
 * package.
 *
 * @author David J. Burger
 * @version $Id: TestWebCrawler.java,v 1.2 2003/12/08 00:56:18 dburger Exp $
 */
class MockWebCrawlerListener implements WebCrawlerListener {

  /** Holds a reference to the returned site report. */
  private WebCrawlerSiteReport siteReport = null;

  /** The user IDs included with the returned site report. */
  private String[] userIds = null;

  /**
   * Called by the <code>WebCrawlerManager</code> when a crawl is complete.
   *
   * @param siteReport the <code>WebCrawlerSiteReport</code> of the crawl
   * @param userIds the array of user IDs associated with the crawl
   */
  public void webCrawlerFinished(WebCrawlerSiteReport siteReport,
      String[] userIds) {
    this.siteReport = siteReport;
    this.userIds = userIds;
    synchronized (this) {
      notifyAll();
    }
  }

  /**
   * Returns the site report from the crawl.
   *
   * @return the <code>WebCrawlerSiteReport</code> from the crawl
   */
  public WebCrawlerSiteReport getWebCrawlerSiteReport() {
    return this.siteReport;
  }

}
