package edu.hawaii.sitewatch.model.webcrawler;

import java.util.TimerTask;

import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;

/**
 * Provides the <code>TimerTask</code> that starts automatic execution of the crawling of root URLs
 * for the Site Watch system at intervals determined by a <code>Timer</code> 
 *
 * @author David J. Burger
 * @version $Id: WebCrawlerTimerTask.java,v 1.1 2003/12/05 19:06:38 dburger Exp $
 */
public class WebCrawlerTimerTask extends TimerTask {

  /**
   * Starts the automatic web crawls for the Site Watch application.
   */
  public void run() {
    SiteWatchAccountManager.getInstance().startAutomaticCrawls();
  }

}