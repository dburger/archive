package edu.hawaii.sitewatch.model.account;

/**
 * Thrown when exceptions occur during account processing.
 *
 * @author dburger
 * @version $Id: SiteWatchAccountException.java,v 1.1 2003/12/05 19:05:43 dburger Exp $
 */
public class SiteWatchAccountException extends Exception {

  /**
   * Thrown when exceptions occur during account processing.
   *
   * @param message the message string describing the error
   */
  public SiteWatchAccountException(String message) {
    super(message);
  }

}
