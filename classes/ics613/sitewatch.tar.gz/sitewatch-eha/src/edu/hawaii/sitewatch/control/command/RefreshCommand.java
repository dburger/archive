package edu.hawaii.sitewatch.control.command;

/**
 * A convenience class with the exact same functionality as DisplayCommand that
 * allows a button with the value "Refresh" to refresh by calling
 * performing the "Display" command.
 *
 * @author David J. Burger
 * @version $Id: RefreshCommand.java,v 1.1 2003/12/02 07:25:57 dburger Exp $
 */
public class RefreshCommand extends DisplayCommand { }
