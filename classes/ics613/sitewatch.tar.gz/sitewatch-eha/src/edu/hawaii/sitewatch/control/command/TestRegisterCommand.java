package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Test the action of register command.
 *
 * @author Fengxian Fan
 * @author David J. Burger (did minor changes)
 * @version $Id: TestRegisterCommand.java,v 1.18 2003/12/08 20:24:44 xiaohua Exp $
 */
public class TestRegisterCommand extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the Register operation under normal situation.
   *
   * @throws Exception If problems occur
   */
  public void testValidRegister () throws Exception {
    WebConversation conversation = new WebConversation();

    // .startsWith test accounts automatically given same password as user ID
    String userId = "test";
    WebResponse response = null;
    int i = -1; // so we start at 0 with first ++

    // loop until we find a test account that can't login, then use that account for registration
    // testing
    do {
      i++;
      // get welcome.jsp page and check for successful retrieval
      response = conversation.getResponse(testHost + "sitewatch/welcome.jsp");
      assertEquals("Expecting welcome.jsp page.", Page.WELCOME.getTitle(), response.getTitle());
      // log out if last loop was a successful login
      WebLink signOutLink = response.getLinkWith("sign out");
      if (signOutLink != null) {
        response = conversation.getResponse(signOutLink.getRequest());
        assertEquals("Expecting to retrieve welcome.jsp page.",
            Page.WELCOME.getTitle(), response.getTitle());
      }
      // now attempt the next test account, a successful login will go to the index.jsp page
      WebForm loginForm = response.getFormWithID("LoginForm");
      WebRequest loginRequest = loginForm.getRequest();
      loginRequest.setParameter("userId", userId + i);
      loginRequest.setParameter("password", userId + i);
      response = conversation.getResponse(loginRequest);
    } while (response.getTitle().equals(Page.INDEX.getTitle()));

    // userId + i is not a valid account, the login failed
    userId += i;

    // now testing registeration with test account userId, get register page
    response = conversation.getResponse(testHost + "sitewatch/register.jsp");
    assertEquals("Expecting register.jsp page.", Page.REGISTER.getTitle(), response.getTitle());

    // now register the account userId
    WebForm registerForm = response.getFormWithID("RegisterForm");
    WebRequest registerRequest = registerForm.getRequest();
    registerRequest.setParameter("userId", userId);
    registerRequest.setParameter("emailAddr", "dburger@hawaii.edu");
    response = conversation.getResponse(registerRequest);

    // check for welcome.jsp page retrieval after successful regitration
    assertEquals("Expecting welcome.jsp page retrieval", Page.WELCOME.getTitle(),
        response.getTitle());

    // now login with the newly registered test account, the password should be the same as user ID
    response = assertLogin(conversation, userId, userId);

    // check that the sitesTable is not present, no sites yet
    WebTable sitesTable = response.getTableWithID("sitesTable");
    assertNull("Expecting the sites table to not be present.", sitesTable);
    
    // now check duplicate registration, first log out
    WebLink signOutLink = response.getLinkWith("sign out");
    response = conversation.getResponse(signOutLink.getRequest());
    assertEquals("Expecting to retrieve welcome.jsp page.",
        Page.WELCOME.getTitle(), response.getTitle());

    // now back to the register page
    response = conversation.getResponse(testHost + "sitewatch/register.jsp");
    assertEquals("Expecting register.jsp page.", Page.REGISTER.getTitle(), response.getTitle());

    // duplicate register
    registerForm = response.getFormWithID("RegisterForm");
    registerRequest = registerForm.getRequest();
    registerRequest.setParameter("userId", userId);
    registerRequest.setParameter("emailAddr", "dburger@hawaii.edu");
    response = conversation.getResponse(registerRequest);

    // should have gone back to register page
    assertEquals ("Expecting redirected back to register.jsp page",
        Page.REGISTER.getTitle(), response.getTitle());

    // and should have an error in the message table
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting duplicate user message.", "User ID " + userId + " is already in use.",
        messageTable.getCellAsText(0, 0));
  }

  /**
   * Tests the Register operation when some filelds are unavailable.
   *
   * @throws Exception If problems occur
   */
  public void testNullFieldRegister () throws Exception {
    WebConversation conversation = new WebConversation();

    // .startsWith test accouns automatically given same password as user ID
    String userId = "test";
    WebResponse response = null;
    int i = -1; // so we start at 0 with first ++

    // loop until we find a test account that can't login, then use that account for registration
    // testing
    do {
      i++;
      // get welcome.jsp page and check for successful retrieval
      response = conversation.getResponse(testHost + "sitewatch/welcome.jsp");
      assertEquals("Expecting welcome.jsp page.", Page.WELCOME.getTitle(), response.getTitle());
      // if the last loop was a successful login, we must log out to get a login form
      WebLink signOutLink = response.getLinkWith("sign out");
      if (signOutLink != null) {
        response = conversation.getResponse(signOutLink.getRequest());
        assertEquals("Expecting to retrieve welcome.jsp page.",
            Page.WELCOME.getTitle(), response.getTitle());
      }
      // now attempt the next test account
      WebForm loginForm = response.getFormWithID("LoginForm");
      WebRequest loginRequest = loginForm.getRequest();
      loginRequest.setParameter("userId", userId + i);
      loginRequest.setParameter("password", userId + i);
      response = conversation.getResponse(loginRequest);
    } while (response.getTitle().equals(Page.INDEX.getTitle()));

    // userId + i is not a valid account, the login failed
    userId += i;

    // test a null field register with the account userId
    response = conversation.getResponse(testHost + "sitewatch/register.jsp");
    assertEquals("Expecting register.jsp page.", Page.REGISTER.getTitle(), response.getTitle());

    // now register the account userId with null field
    WebForm registerForm = response.getFormWithID("RegisterForm");
    WebRequest registerRequest = registerForm.getRequest();
    registerRequest.setParameter("userId", userId);
    // leaving the emailAddr field null
    response = conversation.getResponse(registerRequest);

    // check for register.jsp page retrieval after null field registration
    assertEquals("Expecting welcome.jsp page retrieval", Page.WELCOME.getTitle(),
        response.getTitle());

    // check the content of the messageTable
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting invalid registration message.", "Invaild registration, please provide "
        + "the required items.", messageTable.getCellAsText(0, 0));
  }

}
