﻿namespace GooHelloWorld
{
    partial class GooHelloWorld
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sptMain = new System.Windows.Forms.SplitContainer();
            this.tclMain = new System.Windows.Forms.TabControl();
            this.tabIcons = new System.Windows.Forms.TabPage();
            this.btnInsertIcon = new System.Windows.Forms.Button();
            this.pctIcon = new System.Windows.Forms.PictureBox();
            this.lstIcons = new System.Windows.Forms.ListBox();
            this.tvIconCategories = new System.Windows.Forms.TreeView();
            this.tabKml = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.rtxtKml = new System.Windows.Forms.RichTextBox();
            this.btnLoadKml = new System.Windows.Forms.Button();
            this.tabUnits = new System.Windows.Forms.TabPage();
            this.txtLongName = new System.Windows.Forms.Label();
            this.txtShortName = new System.Windows.Forms.Label();
            this.txtUic = new System.Windows.Forms.Label();
            this.lblLongName = new System.Windows.Forms.Label();
            this.lblShortName = new System.Windows.Forms.Label();
            this.lblUic = new System.Windows.Forms.Label();
            this.lstUnits = new System.Windows.Forms.ListBox();
            this.txtSearchUnits = new System.Windows.Forms.TextBox();
            this.btnSearchUnits = new System.Windows.Forms.Button();
            this.pnlGoogleEarth = new System.Windows.Forms.Panel();
            this.sptMain.Panel1.SuspendLayout();
            this.sptMain.Panel2.SuspendLayout();
            this.sptMain.SuspendLayout();
            this.tclMain.SuspendLayout();
            this.tabIcons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctIcon)).BeginInit();
            this.tabKml.SuspendLayout();
            this.tabUnits.SuspendLayout();
            this.SuspendLayout();
            // 
            // sptMain
            // 
            this.sptMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.sptMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sptMain.Location = new System.Drawing.Point(0, 0);
            this.sptMain.Name = "sptMain";
            this.sptMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // sptMain.Panel1
            // 
            this.sptMain.Panel1.Controls.Add(this.tclMain);
            this.sptMain.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // sptMain.Panel2
            // 
            this.sptMain.Panel2.Controls.Add(this.pnlGoogleEarth);
            this.sptMain.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.sptMain.Size = new System.Drawing.Size(814, 525);
            this.sptMain.SplitterDistance = 193;
            this.sptMain.TabIndex = 10;
            // 
            // tclMain
            // 
            this.tclMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tclMain.Controls.Add(this.tabIcons);
            this.tclMain.Controls.Add(this.tabKml);
            this.tclMain.Controls.Add(this.tabUnits);
            this.tclMain.Location = new System.Drawing.Point(3, 3);
            this.tclMain.Name = "tclMain";
            this.tclMain.SelectedIndex = 0;
            this.tclMain.Size = new System.Drawing.Size(804, 183);
            this.tclMain.TabIndex = 10;
            // 
            // tabIcons
            // 
            this.tabIcons.Controls.Add(this.btnInsertIcon);
            this.tabIcons.Controls.Add(this.pctIcon);
            this.tabIcons.Controls.Add(this.lstIcons);
            this.tabIcons.Controls.Add(this.tvIconCategories);
            this.tabIcons.Location = new System.Drawing.Point(4, 22);
            this.tabIcons.Name = "tabIcons";
            this.tabIcons.Padding = new System.Windows.Forms.Padding(3);
            this.tabIcons.Size = new System.Drawing.Size(796, 157);
            this.tabIcons.TabIndex = 0;
            this.tabIcons.Text = "Icons";
            this.tabIcons.UseVisualStyleBackColor = true;
            // 
            // btnInsertIcon
            // 
            this.btnInsertIcon.Location = new System.Drawing.Point(541, 6);
            this.btnInsertIcon.Name = "btnInsertIcon";
            this.btnInsertIcon.Size = new System.Drawing.Size(75, 23);
            this.btnInsertIcon.TabIndex = 10;
            this.btnInsertIcon.Text = "Insert Icon";
            this.btnInsertIcon.UseVisualStyleBackColor = true;
            this.btnInsertIcon.Click += new System.EventHandler(this.btnInsertIcon_Click);
            // 
            // pctIcon
            // 
            this.pctIcon.Location = new System.Drawing.Point(396, 6);
            this.pctIcon.Name = "pctIcon";
            this.pctIcon.Size = new System.Drawing.Size(139, 81);
            this.pctIcon.TabIndex = 9;
            this.pctIcon.TabStop = false;
            // 
            // lstIcons
            // 
            this.lstIcons.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.lstIcons.FormattingEnabled = true;
            this.lstIcons.Location = new System.Drawing.Point(201, 6);
            this.lstIcons.Name = "lstIcons";
            this.lstIcons.Size = new System.Drawing.Size(189, 134);
            this.lstIcons.TabIndex = 8;
            this.lstIcons.SelectedIndexChanged += new System.EventHandler(this.lstIcons_SelectedIndexChanged);
            // 
            // tvIconCategories
            // 
            this.tvIconCategories.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.tvIconCategories.HideSelection = false;
            this.tvIconCategories.Location = new System.Drawing.Point(6, 6);
            this.tvIconCategories.Name = "tvIconCategories";
            this.tvIconCategories.Size = new System.Drawing.Size(189, 145);
            this.tvIconCategories.TabIndex = 7;
            this.tvIconCategories.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvIconCategories_BeforeExpand);
            this.tvIconCategories.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvIconCategories_AfterSelect);
            // 
            // tabKml
            // 
            this.tabKml.Controls.Add(this.button1);
            this.tabKml.Controls.Add(this.rtxtKml);
            this.tabKml.Controls.Add(this.btnLoadKml);
            this.tabKml.Location = new System.Drawing.Point(4, 22);
            this.tabKml.Name = "tabKml";
            this.tabKml.Padding = new System.Windows.Forms.Padding(3);
            this.tabKml.Size = new System.Drawing.Size(796, 157);
            this.tabKml.TabIndex = 1;
            this.tabKml.Text = "KML";
            this.tabKml.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(87, 116);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rtxtKml
            // 
            this.rtxtKml.Location = new System.Drawing.Point(154, 9);
            this.rtxtKml.Name = "rtxtKml";
            this.rtxtKml.Size = new System.Drawing.Size(190, 75);
            this.rtxtKml.TabIndex = 11;
            this.rtxtKml.Text = "";
            // 
            // btnLoadKml
            // 
            this.btnLoadKml.Location = new System.Drawing.Point(6, 6);
            this.btnLoadKml.Name = "btnLoadKml";
            this.btnLoadKml.Size = new System.Drawing.Size(142, 25);
            this.btnLoadKml.TabIndex = 10;
            this.btnLoadKml.Text = "Load KML";
            this.btnLoadKml.UseVisualStyleBackColor = true;
            // 
            // tabUnits
            // 
            this.tabUnits.Controls.Add(this.txtLongName);
            this.tabUnits.Controls.Add(this.txtShortName);
            this.tabUnits.Controls.Add(this.txtUic);
            this.tabUnits.Controls.Add(this.lblLongName);
            this.tabUnits.Controls.Add(this.lblShortName);
            this.tabUnits.Controls.Add(this.lblUic);
            this.tabUnits.Controls.Add(this.lstUnits);
            this.tabUnits.Controls.Add(this.txtSearchUnits);
            this.tabUnits.Controls.Add(this.btnSearchUnits);
            this.tabUnits.Location = new System.Drawing.Point(4, 22);
            this.tabUnits.Name = "tabUnits";
            this.tabUnits.Size = new System.Drawing.Size(796, 157);
            this.tabUnits.TabIndex = 2;
            this.tabUnits.Text = "Units";
            this.tabUnits.UseVisualStyleBackColor = true;
            // 
            // txtLongName
            // 
            this.txtLongName.AutoSize = true;
            this.txtLongName.Location = new System.Drawing.Point(454, 56);
            this.txtLongName.Name = "txtLongName";
            this.txtLongName.Size = new System.Drawing.Size(0, 13);
            this.txtLongName.TabIndex = 8;
            // 
            // txtShortName
            // 
            this.txtShortName.AutoSize = true;
            this.txtShortName.Location = new System.Drawing.Point(454, 34);
            this.txtShortName.Name = "txtShortName";
            this.txtShortName.Size = new System.Drawing.Size(0, 13);
            this.txtShortName.TabIndex = 7;
            // 
            // txtUic
            // 
            this.txtUic.AutoSize = true;
            this.txtUic.Location = new System.Drawing.Point(454, 10);
            this.txtUic.Name = "txtUic";
            this.txtUic.Size = new System.Drawing.Size(0, 13);
            this.txtUic.TabIndex = 6;
            // 
            // lblLongName
            // 
            this.lblLongName.AutoSize = true;
            this.lblLongName.Location = new System.Drawing.Point(382, 56);
            this.lblLongName.Name = "lblLongName";
            this.lblLongName.Size = new System.Drawing.Size(65, 13);
            this.lblLongName.TabIndex = 5;
            this.lblLongName.Text = "Long Name:";
            // 
            // lblShortName
            // 
            this.lblShortName.AutoSize = true;
            this.lblShortName.Location = new System.Drawing.Point(382, 34);
            this.lblShortName.Name = "lblShortName";
            this.lblShortName.Size = new System.Drawing.Size(66, 13);
            this.lblShortName.TabIndex = 4;
            this.lblShortName.Text = "Short Name:";
            // 
            // lblUic
            // 
            this.lblUic.AutoSize = true;
            this.lblUic.Location = new System.Drawing.Point(420, 10);
            this.lblUic.Name = "lblUic";
            this.lblUic.Size = new System.Drawing.Size(28, 13);
            this.lblUic.TabIndex = 3;
            this.lblUic.Text = "UIC:";
            // 
            // lstUnits
            // 
            this.lstUnits.FormattingEnabled = true;
            this.lstUnits.Location = new System.Drawing.Point(172, 3);
            this.lstUnits.Name = "lstUnits";
            this.lstUnits.Size = new System.Drawing.Size(197, 147);
            this.lstUnits.TabIndex = 2;
            this.lstUnits.SelectedIndexChanged += new System.EventHandler(this.lstUnits_SelectedIndexChanged);
            // 
            // txtSearchUnits
            // 
            this.txtSearchUnits.Location = new System.Drawing.Point(3, 3);
            this.txtSearchUnits.Name = "txtSearchUnits";
            this.txtSearchUnits.Size = new System.Drawing.Size(163, 20);
            this.txtSearchUnits.TabIndex = 1;
            // 
            // btnSearchUnits
            // 
            this.btnSearchUnits.Location = new System.Drawing.Point(3, 29);
            this.btnSearchUnits.Name = "btnSearchUnits";
            this.btnSearchUnits.Size = new System.Drawing.Size(75, 23);
            this.btnSearchUnits.TabIndex = 0;
            this.btnSearchUnits.Text = "Search";
            this.btnSearchUnits.UseVisualStyleBackColor = true;
            this.btnSearchUnits.Click += new System.EventHandler(this.btnSearchUnits_Click);
            // 
            // pnlGoogleEarth
            // 
            this.pnlGoogleEarth.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlGoogleEarth.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pnlGoogleEarth.Location = new System.Drawing.Point(3, 3);
            this.pnlGoogleEarth.Name = "pnlGoogleEarth";
            this.pnlGoogleEarth.Size = new System.Drawing.Size(800, 318);
            this.pnlGoogleEarth.TabIndex = 6;
            this.pnlGoogleEarth.Resize += new System.EventHandler(this.pnlGoogleEarth_Resize);
            // 
            // GooHelloWorld
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 524);
            this.Controls.Add(this.sptMain);
            this.Name = "GooHelloWorld";
            this.Text = "GooHelloWorld";
            this.Load += new System.EventHandler(this.GooHelloWorld_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GooHelloWorld_FormClosing);
            this.sptMain.Panel1.ResumeLayout(false);
            this.sptMain.Panel2.ResumeLayout(false);
            this.sptMain.ResumeLayout(false);
            this.tclMain.ResumeLayout(false);
            this.tabIcons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pctIcon)).EndInit();
            this.tabKml.ResumeLayout(false);
            this.tabUnits.ResumeLayout(false);
            this.tabUnits.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer sptMain;
        private System.Windows.Forms.TabControl tclMain;
        private System.Windows.Forms.TabPage tabIcons;
        private System.Windows.Forms.Button btnInsertIcon;
        private System.Windows.Forms.PictureBox pctIcon;
        private System.Windows.Forms.ListBox lstIcons;
        private System.Windows.Forms.TreeView tvIconCategories;
        private System.Windows.Forms.TabPage tabKml;
        private System.Windows.Forms.RichTextBox rtxtKml;
        private System.Windows.Forms.Button btnLoadKml;
        private System.Windows.Forms.Panel pnlGoogleEarth;
        private System.Windows.Forms.TabPage tabUnits;
        private System.Windows.Forms.TextBox txtSearchUnits;
        private System.Windows.Forms.Button btnSearchUnits;
        private System.Windows.Forms.ListBox lstUnits;
        private System.Windows.Forms.Label txtLongName;
        private System.Windows.Forms.Label txtShortName;
        private System.Windows.Forms.Label txtUic;
        private System.Windows.Forms.Label lblLongName;
        private System.Windows.Forms.Label lblShortName;
        private System.Windows.Forms.Label lblUic;
        private System.Windows.Forms.Button button1;
    }
}

