package edu.hawaii.sitewatch.util;

import javax.servlet.ServletContext;

/**
 * A singleton class that provides access to methods useful to the Site Watch application such as
 * logging or retrieving initialization parameters.  Many of the methods of this class merely relay
 * the given call to a <code>ServletContext</code> instance that is set with the <code>init</code>
 * method.  Methods have been written to return defaults when the <code>ServletContext</code> is
 * not available to handle unit tests that do not run in conjunction with the servlet.
 *
 * @author David J. Burger
 * @version $Id: ServletUtils.java,v 1.5 2003/12/05 23:06:48 dburger Exp $
 */
public class ServletUtils {

  // Currently this class uses composition to hold a reference to the ServletContext for this
  // application and forwards method calls to it.  This class would also be the class that you would
  // add any application wide useful functions to.

  /** The singleton <code>ServletUtils</code> instance. */
  private static ServletUtils theInstance = null;

  /** Will hold a reference to the <code>ServletContext</code> for this app. */
  private ServletContext servletContext = null;

  /**
   * Used to retrieve the singleton <code>ServletUtils</code>.
   *
   * @return the singleton <code>ServletUtils</code>.
   */
  public static synchronized ServletUtils getInstance() {
    if (ServletUtils.theInstance == null) {
      ServletUtils.theInstance = new ServletUtils();
    }
    return ServletUtils.theInstance;
  }

  /**
   * Used to initialize the singleton <code>ServerUtils</code> by setting the
   * <code>ServletContext</code> so that it can be used to process further
   * calls.
   *
   * @param servletContext the <code>ServletContext</code> for this application
   */
  public void init(ServletContext servletContext) {
    this.servletContext = servletContext;
  }

  /**
   * Wites the specified message to the servlet log file.  If the <code>ServletContext</code> is
   * not available this method merely returns.
   *
   * @param message the message to write to the log file
   */
  public void log(String message) {
    if (this.servletContext == null) {
      return;
    }
    this.servletContext.log(message);
  }


  /**
   * Writes the specified message to the servlet log file followed by the stack trace of the
   * given <code>Throwable</code>.  If the <code>ServletContext</code> is not available this
   * method merely returns.
   *
   * @param message the message to write to the log file
   * @param throwable the <code>Throwable</code> to use to write a stack trace
   *     to the log file
   */
  public void log(String message, Throwable throwable) {
    if (this.servletContext == null) {
      return;
    }
    this.servletContext.log(message, throwable);
  }

  /**
   * Returns a <code>String</code> containing the value of the named context-
   * wide initialization parameter, or the default value if the parameter does
   * not exist or the <code>ServletContext</code> is not available.
   *
   * @param name a <code>String</code> containing the name of the parameter
   *     whose value is requested
   * @param defaultValue the value to return if context-param <code>name</code> is not found 
   * @return the <code>String</code> parameter value or the default value if it does not
   *     exist or the <code>ServletContext</code> is not available
   */
  public String getInitParameter(String name, String defaultValue) {
    String value = null;
    if (this.servletContext != null) {
      value = this.servletContext.getInitParameter(name);
    }
    return (value != null) ? value : defaultValue;
  }

  /**
   * Returns a the int value of the named context-wide initialization 
   * parameter, or the default value if it doesn't exist or can't be
   * converted into an int or if the <code>ServletContext</code> is not
   * available.
   *
   * @param name a <code>String</code> containing the name of the parameter
   *     whose value is requested
   * @param defaultValue the value to return if the named context parameter doesn't
   *     exist or can't be converted to an int
   * @return the int parameter value or the default value
   */
  public int getInitParameter(String name, int defaultValue) {
    if (this.servletContext != null) {
      try {
        defaultValue = Integer.parseInt(this.servletContext.getInitParameter(name));
      }
      catch (Exception e) {
        // leave as defaultValue
      }
    }
    return defaultValue;
  }

  /**
   * Returns a String containing the real path for a given virtual path.  If the
   * <code>ServletContext</code> is not available this method merely returns the
   * given path.
   *
   * @param path a <code>String</code> specifying a virtual path
   * @return a <code>String</code> specifying the real path, which will be null if the
   *     translation cannot be performed, or the given path if the
   *     <code>ServletContext</code> is not available
   */
  public String getRealPath(String path) {
    if (this.servletContext == null) {
      return path;
    }
    return this.servletContext.getRealPath(path);
  }

}
