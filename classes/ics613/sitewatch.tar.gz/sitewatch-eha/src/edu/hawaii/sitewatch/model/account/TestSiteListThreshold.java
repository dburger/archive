package edu.hawaii.sitewatch.model.account;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.util.ServletUtils;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests the operation of the Site Watch application rejecting the addition of sites to a user's
 * account when the addition would cause them to go over the siteThreshold value from the
 * context-params.
 *
 * @author David J. Burger
 * @version $Id: TestSiteListThreshold.java,v 1.2 2003/12/06 22:15:28 dburger Exp $
 */
public class TestSiteListThreshold extends SiteWatchTestCase {

  /**
   * Tests the site watch application's ability to reject site additions that cause a user's account
   * to have more sites than that allowed by the siteThreshold context-param.
   *
   * @throws Exception If problems occur
   */
  public void testSiteListThreshold() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";
    
    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    int siteThreshold = ServletUtils.getInstance().getInitParameter("siteThreshold", 50);
    
    // keep adding until we have added the maximum allowed
    int i = 0;
    for (; i < siteThreshold; i++) {
      response = assertAddSite(conversation, response, "http://" + i + ".com", false);
    }

    // now add the one that causes us to go over the siteThreshold
    WebForm addForm = response.getFormWithID("AddSiteForm");
    WebRequest addRequest = addForm.getRequest();
    addRequest.setParameter("newSite", "http://" + i + ".com");
    response = conversation.getResponse(addRequest);

    // check that the last add didn't work, that is we have siteThreshold URLs
    // + header/select all/buttons in the sitesTable
    WebTable sitesTable = response.getTableWithID("sitesTable");
    assertEquals("Expecting table size of " + (siteThreshold + 3) + ".", siteThreshold + 3,
        sitesTable.getRowCount());

    // check that we got the message saying that we can't add anymore
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting message saying we can't add the last url.", "You have reached the site "
        + "threshold limit. You will be unable to add http://" + siteThreshold + ".com unless you "
        + "remove a site.", messageTable.getCellAsText(0, 0));

    // remove all our added urls
    for (i = 0; i < siteThreshold; i++) {
      response = assertRemoveSite(conversation, response, "http://" + i + ".com");
    }
  }

}
