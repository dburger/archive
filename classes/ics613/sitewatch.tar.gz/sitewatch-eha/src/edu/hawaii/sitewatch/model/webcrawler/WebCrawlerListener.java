package edu.hawaii.sitewatch.model.webcrawler;

/**
 * Interface implemented by classes wishing to receive the
 * <code>WebCrawlerSiteReport</code> in a callback from a
 * <code>WebCrawler</code> upon crawl completion.
 *
 * @author David J. Burger
 * @version $Id: WebCrawlerListener.java,v 1.1 2003/12/05 19:06:38 dburger Exp $
 */
public interface WebCrawlerListener {

  /**
   * Called by the <code>WebCrawlerManager</code> when a crawl is finished.
   *
   * @param siteReport contains the <code>WebCrawlerSiteReport</code> of the
   *     crawl
   * @param userIds the list of user IDs associated with the report
   */
  public void webCrawlerFinished(WebCrawlerSiteReport siteReport, String[] userIds);

}
