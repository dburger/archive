package edu.hawaii.sitewatch.model.webcrawler;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests operation of site watch application identifying modified pages.
 *
 * @author David J. Burger
 * @version $Id: TestSiteModifiedPages.java,v 1.4 2003/12/07 21:01:35 dburger Exp $
 */
public class TestSiteModifiedPages extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the site watch application's ability to identify modified pages.
   *
   * @throws Exception If problems occur
   */
  public void testModifiedPages() throws Exception {
    String url = testHost + "test-sitewatch/modified/";
    // getCellAsText removes markup so this will be smushed together
    String columnHeader = "ModifiedPages";
    String expectedValue = "3";

    WebConversation conversation = new WebConversation();

    String userId = "testcrawler";
    String password = "testcrawler";

    // login with the testcrawler account
    WebResponse response = assertLogin(conversation, userId, password);

    // now choose url for manual crawl
    response = assertStartCrawl(conversation, response, url);

    // make sure the crawl has time to finish, 5 seconds should be enough
    synchronized (this) {
      wait(5000);
    }

    // now refresh to get updated result from crawl
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());

    // and check that we have the expected value
    assertSitesTableValue(response, url, columnHeader, expectedValue);
  }

}
