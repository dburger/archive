package edu.hawaii.sitewatch.control.command;

import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountManager;
import edu.hawaii.sitewatch.model.account.SiteWatchAccountException;
import edu.hawaii.sitewatch.util.Mailer;
import edu.hawaii.sitewatch.util.ServletUtils;

/**
 * Implements the Register command.
 *
 * @author Xiaohua Chen
 * @author David J. Burger (minor changes)
 * @author Fengxian Fan (add functionality to send password to user)
 * @version $Id: RegisterCommand.java,v 1.32 2003/12/05 19:07:56 dburger Exp $
 */
public class RegisterCommand implements Command {

  /**
   * Processes the "Register" command sent by the user.
   *
   * @param request The request object.
   * @return The page to be displayed (Page.INDEX on valid login,
   *   Page.WELCOME on invalid login)
   */
  public Page process(HttpServletRequest request) {
    HttpSession session = request.getSession();

    // only changed to Page.WELCOME if registration is OK
    Page returnPage = Page.REGISTER;

    // retrieve the form fields
    String userId = request.getParameter("userId");
    String emailAddr = request.getParameter("emailAddr");

    // set so that if sent back to register values will be filled in
    request.setAttribute("userId", userId);
    request.setAttribute("emailAddr", emailAddr);

    if (userId == null || emailAddr == null || userId.length() == 0 || emailAddr.length() == 0) {
      request.setAttribute("message", "Invaild registration, please provide the required items.");
      // leave returnPage == Page.REGISTER
    }
    else {
      SiteWatchAccountManager manager = SiteWatchAccountManager.getInstance();
      ServletUtils servletUtils = ServletUtils.getInstance();
      try {
        int passwordCharCount = servletUtils.getInitParameter("numGeneratedPasswordChars", 12);
        // for testing, any account where the userId starts with "test" automatically gets a
        // password that is the same as the user ID
        String password = userId.startsWith("test") ? userId : generatePassword(passwordCharCount);
        String fromAddress =
            servletUtils.getInitParameter("fromAddress", "sitewatch@sitewatch.com");
        Mailer.getInstance().send(fromAddress, emailAddr, "Site Watch account information",
            "If you are receiving this email then that means you have successfully registered for a"
            + " Site Watch account.  Your user ID is " + userId + " and your passowrd is "
            + password);
        manager.createSiteWatchAccount(userId, emailAddr, password);
        request.setAttribute("message", "Thank you for registering for Site Watch.  Your user ID "
            + "is " + userId + ".  After you receive your password in an email in a few minutes, "
            + "you can use this page to login.");
        returnPage = Page.WELCOME;
      }
      catch (AddressException e) {
        request.setAttribute("message", e.getMessage());
        returnPage = Page.REGISTER;
      }
      catch (MessagingException e) {
        request.setAttribute("message", e.getMessage());
        returnPage = Page.REGISTER;
      }
      catch (SiteWatchAccountException e) {
        request.setAttribute("message", e.getMessage());
        // so far the only thing we catch is duplicate account, so clear userId
        request.setAttribute("userId", "");
        // leave returnPage == Page.REGISTER
      }
    }
    return returnPage;
  }

  /**
   * Generates and returns a random password of length charCount.
   *
   * @param charCount the number of characters for the generated password
   * @return the generated random password of length <code>charCount</code>
   */
  private String generatePassword(int charCount) {

    StringBuffer password = new StringBuffer("");
    Random random = new Random();

    for (int i = 0; i < charCount; i++) {
      int value = random.nextInt(62);
      if (value < 10) {
        // 0-9 is 0-9
        value += '0';
      }
      else if (value < 36) {
        // 10-35 is A-Z
        value += ('A' - 10);
      }
      else {
        // 36-61 is a-z
        value += ('a' - 36);
      }
      password.append((char) value);
    }

    return password.toString();
  }

}
