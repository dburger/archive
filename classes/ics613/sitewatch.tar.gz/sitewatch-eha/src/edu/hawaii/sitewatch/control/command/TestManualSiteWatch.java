package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests operation of manual initiation of site watch crawls.
 *
 * @author David J. Burger
 * @version $Id: TestManualSiteWatch.java,v 1.11 2003/12/07 21:01:35 dburger Exp $
 */
public class TestManualSiteWatch extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the Crawl operation under normal situation.
   *
   * @throws Exception If problems occur
   */
  public void testManualCrawl() throws Exception {
    String url = testHost + "test-sitewatch/one/";

    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add url to the site watch list
    response = assertAddSite(conversation, response, url, false);

    // now choose url for manual crawl
    response = assertStartCrawl(conversation, response, url);

    // now check that it is listed as in progress, it should have an asterisk
    WebTable sitesTable = response.getTableWithID("sitesTable");
    assertTrue("Expecting site to be listed as having a crawl in progress.",
        sitesTable.getCellAsText(1, 1).indexOf("*") == 0);

    // make sure the crawl has time to finish, 5 seconds should be enough
    synchronized (this) {
      wait(5000);
    }

    // now refresh and check that has been crawled
    response = conversation.getResponse(testHost + "sitewatch/controller");
    assertEquals("Expecting index.jsp page.", Page.INDEX.getTitle(), response.getTitle());

    // the asterisk should be gone
    sitesTable = response.getTableWithID("sitesTable");
    assertFalse("Expecting no crawl in progress asterisk.",
        sitesTable.getCellAsText(1, 1).substring(0, 1).equals("*"));

    // and the rest of the values should be filled in
    for (int i = 2; i < 7; i++) {
      assertFalse("Expecting table cells to contain crawl data.",
          sitesTable.getCellAsText(1, i).equals(""));
    }

    // clean up by removing url
    assertRemoveSite(conversation, response, url);
  }

}
