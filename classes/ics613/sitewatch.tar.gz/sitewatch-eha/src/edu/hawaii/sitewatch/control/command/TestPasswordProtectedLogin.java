package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests the action of validation of login.
 *
 * @author Fengxian Fan
 * @author David J. Burger (did minor changes)
 * @version $Id: TestPasswordProtectedLogin.java,v 1.6 2003/12/08 20:24:51 xiaohua Exp $
 */
public class TestPasswordProtectedLogin extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the valid Login operation.
   *
   * @throws Exception If problems occur
   */
  public void testValidLogin () throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";

    // login with the test account
    assertLogin(conversation, userId, password);
  }

  /**
   * Tests the Login operation with invalid login.
   *
   * @throws Exception If problems occur
   */
  public void testInvalidLogin () throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "invalid";
    String password = "invalid";

    // go to the welcome page and check for successful retrieval
    WebResponse response = conversation.getResponse(testHost + "sitewatch/welcome.jsp");
    assertEquals("Expecting welcome.jsp page.", Page.WELCOME.getTitle(), response.getTitle());

    // now login with the invalid account
    WebForm loginForm = response.getFormWithID("LoginForm");
    WebRequest loginRequest = loginForm.getRequest();
    loginRequest.setParameter("userId", userId);
    loginRequest.setParameter("password", password);
    response = conversation.getResponse(loginRequest);

    // should have gone back to the welcome page
    assertEquals ("Expecting welcome.jsp page retrieval",
        Page.WELCOME.getTitle(), response.getTitle());

    // and we should have an error message
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting invalid login message.", "Invaild user name or password, please check "
        + "and try again.", messageTable.getCellAsText(0, 0));
  }

  /**
   * Tests the Login operation with a valid user supplying the wrong password.
   *
   * @throws Exception If problems occur
   */
  public void testWrongPassword () throws Exception {
    WebConversation conversation = new WebConversation();

    // get welcome.jsp page and check for successful retrieval
    WebResponse response = conversation.getResponse(testHost + "sitewatch/welcome.jsp");
    assertEquals("Expecting welcome.jsp page.", Page.WELCOME.getTitle(), response.getTitle());

    // login with the test account with an invalid password
    String userId = "test";
    String password = "invalid";
    WebForm loginForm = response.getFormWithID("LoginForm");
    WebRequest loginRequest = loginForm.getRequest();
    loginRequest.setParameter("userId", userId);
    loginRequest.setParameter("password", password);
    response = conversation.getResponse(loginRequest);

    // should have gone back to the welcome page
    assertEquals ("Expecting welcome.jsp page retrieval",
        Page.WELCOME.getTitle(), response.getTitle());

    // and we should have an error message
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting invalid login message.", "Invaild user name or password, please check "
        + "and try again.", messageTable.getCellAsText(0, 0));
  }

}
