package edu.hawaii.sitewatch.model.site;

import java.io.Serializable;

/**
 * Holds the information of the site: site url, whether the site needs email
 * notification when changes are checked, and the report on the crawlering results
 *
 * @author Fengxian Fan
 * @version $Id: WatchedSite.java,v 1.1 2003/12/05 19:06:11 dburger Exp $
 */
public class WatchedSite implements Serializable {

  /** URL of the site which will be watched */
  private String url;

  /** A flag indicating whether the site crawlering results should be emailed to the user */
  private boolean triggersEmail;

  /** A <code>WatchedSiteReport</code> on the crawlering results */
  private WatchedSiteReport siteReport;

  /**
   * Constractor with the given url, email alert flag and <code>WatchedSiteReport</code>
   *
   * @param url the url for this site
   * @param triggersEmail the flag for triggering email sending
   * @param siteReport the crawlering result report for this url
   */
  public WatchedSite(String url, boolean triggersEmail, WatchedSiteReport siteReport) {
    this.url = url;
    this.triggersEmail = triggersEmail;
    this.siteReport = siteReport;
  }

  /**
   * Returns the URL of this <code>WatchedSite</code>.
   *
   * @return the URL of this <code>WatchedSite</code>
   */
  public String getUrl() {
    return this.url;
  }

  /**
   * Sets the <code>WatchedSiteReport</code> for this <code>WatchedSite</code>.
   *
   * @param siteReport the new site report for this <code>WatchedSite</code>
   */
  public void setSiteReport(WatchedSiteReport siteReport) {
    this.siteReport = siteReport;
  }

  /**
   * Gets a <code>WatchedSiteReport</code>
   *
   * @return a <code>WatchedSiteReport</code>
   */
  public WatchedSiteReport getSiteReport() {
    return this.siteReport;
  }

  /**
   * Gets the <code>triggersEmail</code>
   *
   * @return triggersEmail the flag for triggering email sending
   */
  public boolean getTriggersEmail() {
    return this.triggersEmail;
  }

  /**
   * Used to set whether or not site reports generated for this
   * <code>WatchedSite</code> generate email alerts.
   *
   * @param triggersEmail flag that indicates if site reports generate email
   *     alerts for this <code>WatchedSite</code>
   */
  public void setTriggersEmail(boolean triggersEmail) {
    this.triggersEmail = triggersEmail;
  }

}
