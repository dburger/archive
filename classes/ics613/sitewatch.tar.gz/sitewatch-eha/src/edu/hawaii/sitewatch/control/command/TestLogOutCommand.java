package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.control.Page;
import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests the action of log out command under normal conditions.
 *
 * @author Fengxian Fan
 * @author David J. Burger (did minor changes)
 *
 * @version $Id: TestLogOutCommand.java,v 1.14 2003/12/08 20:24:56 xiaohua Exp $
 */
public class TestLogOutCommand extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the LogOut operation under normal situation.
   *
   * @throws Exception If problems occur
   */
  public void testLogout () throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // check LogOut command works, first log out
    WebLink signOutLink = response.getLinkWith("sign out");
    response = conversation.getResponse(signOutLink.getRequest());

    // now check that directed back to the welcome page
    assertEquals("Expecting to retrieve welcome.jsp page.",
        Page.WELCOME.getTitle(), response.getTitle());

    // and we should have an error message
    WebTable messageTable = response.getTableWithID("messageTable");
    assertEquals("Expecting goodbye message.", "Goodbye, thank you for using Site Watch!",
        messageTable.getCellAsText(0, 0));
  }

}
