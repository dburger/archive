package edu.hawaii.sitewatch.control.command;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebTable;

import edu.hawaii.sitewatch.util.SiteWatchTestCase;

/**
 * Tests operation of the Add command.
 *
 * @author Xiaohua Chen
 * @author David J. Burger
 * @author Fengxian Fan
 * @version $Id: TestSiteAddition.java,v 1.9 2003/12/08 20:24:38 xiaohua Exp $
 */
public class TestSiteAddition extends SiteWatchTestCase {

  /** Get the test host. */
  private String testHost = System.getProperty("test.host");

  /**
   * Tests the Add site operation under normal condition.
   *
   * @throws Exception If problems occur
   */
  public void testAdd() throws Exception {
    WebConversation conversation = new WebConversation();

    String userId = "test";
    String password = "test";
    String url1 = "http://csdl.ics.hawaii.edu";
    String url2 = "http://www.ics.hawaii.edu";

    // login with the test account
    WebResponse response = assertLogin(conversation, userId, password);

    // add the URL onto the sitewatch
    response = assertAddSite(conversation, response, url1, false);

    // now add a second URL into watch
    response = assertAddSite(conversation, response, url2, false);

    // add the same URL as above
    WebForm addForm = response.getFormWithID("AddSiteForm");
    WebRequest addRequest = addForm.getRequest();
    addRequest.setParameter("newSite", url1);
    response = conversation.getResponse(addRequest);

    // now check that the row count hasn't changed...rejects duplicates
    WebTable sitesTable = response.getTableWithID("sitesTable");
    assertEquals("Expecting table size of 5, rejected duplicate.", 5, sitesTable.getRowCount());

    // clean up after ourselves by removing our added URLs, the first one
    response = assertRemoveSite(conversation, response, url1);

    // and the second one
    assertRemoveSite(conversation, response, url2);
  }

}
